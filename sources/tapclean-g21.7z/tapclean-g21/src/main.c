/*
 * main.c  (Final TAP 2.7.x console version).
 *
 * Part of project "Final TAP".
 *
 * A Commodore 64 tape remastering and data extraction utility.
 *
 * (C) 2001-2006 Stewart Wilson, Subchrist Software.
 *
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
 * St, Fifth Floor, Boston, MA 02110-1301 USA
 *
 */

#ifdef WIN32
#include <direct.h>
#include <windows.h>
#else
#include <unistd.h>
#endif

#include "main.h"
#include "mydefs.h"
#include "crc32.h"
#include "tap2audio.h"

/* program options... */

static char noaddpause  = FALSE;
static char sine        = FALSE;
static char doprg       = FALSE;

char debug              = FALSE;
char noid               = FALSE;
char noc64eof           = FALSE;
char docyberfault       = FALSE;
char boostclean         = FALSE;
char prgunite           = FALSE;
char extvisipatch       = FALSE;
char incsubdirs         = FALSE;
char sortbycrc          = FALSE;
char c16                = FALSE;
char c20                = FALSE;
char c64                = TRUE;
char pal                = TRUE;
char ntsc               = FALSE;

char exportcyberloaders = FALSE;

static char preserveloadertable = TRUE;

/*
parameters -no/do and descriptions
*/
struct _ldrswt{
    char desc[24];
    char par[12];
    char shortpar[12];
    char state;
}ldrswt[]=
{
   {"C64 ROM loader"          ,"c64"        ,"64" ,FALSE}
  ,{"Accolade/EA"             ,"accolade"   ,"ea" ,FALSE}
  ,{"Ace of Aces"             ,"aces"       ,"ac" ,FALSE}
  ,{"ActionReplay"            ,"ar"         ,"ar" ,FALSE}
  ,{"Alien Syndrome"          ,"aliensy"    ,"as" ,FALSE}
  ,{"Alternative World Games" ,"alterwg"    ,"aw" ,FALSE}
  ,{"Anirog"                  ,"anirog"     ,"an" ,FALSE}
  ,{"Ash+Dave"                ,"ashdave"    ,"ad" ,FALSE}
  ,{"Atlantis"                ,"atlantis"   ,"at" ,FALSE}
  ,{"Audiogenic"              ,"audiogenic" ,"au" ,FALSE}
  ,{"Bleepload"               ,"bleep"      ,"bl" ,FALSE}
  ,{"Burner"                  ,"burner"     ,"bu" ,FALSE}
  ,{"Burner Variant"          ,"burnervar"  ,"bv" ,FALSE}
  ,{"CHR"                     ,"chr"        ,"ch" ,FALSE}
  ,{"Cult"                    ,"cult"       ,"cu" ,FALSE}
  ,{"Cyberload"               ,"cyber"      ,"cy" ,FALSE}
  ,{"Easytape"                ,"easytape"   ,"et" ,FALSE}
  ,{"Enigma"                  ,"enigma"     ,"en" ,FALSE}
  ,{"Firebird"                ,"fire"       ,"fb" ,FALSE}
  ,{"Flashload"               ,"flash"      ,"fl" ,FALSE}
  ,{"Freeload"                ,"free"       ,"fr" ,FALSE}
  ,{"Freeload Slowload"       ,"frslow"     ,"fs" ,FALSE}
  ,{"FreezeFrame"             ,"freezeframe","ff" ,FALSE}
  ,{"Galadriel"               ,"galadriel"  ,"ga" ,FALSE}
  ,{"Hitload"                 ,"hit"        ,"hl" ,FALSE}
  ,{"Hi-Tec"                  ,"hitec"      ,"hi" ,FALSE}
  ,{"IK"                      ,"ik"         ,"ik" ,FALSE}
  ,{"Jetload"                 ,"jet"        ,"jt" ,FALSE}
  ,{"Load'n'Run"              ,"loadnrun"   ,"lr" ,FALSE}
  ,{"Microload"               ,"micro"      ,"mi" ,FALSE}
  ,{"Next"                    ,"next"       ,"ne" ,FALSE}
  ,{"Novaload"                ,"nova"       ,"nl" ,FALSE}
  ,{"Ocean"                   ,"ocean"      ,"oc" ,FALSE}
  ,{"Ocean F1"                ,"oceannew1t1","o1" ,FALSE}
  ,{"Ocean F2"                ,"oceannew1t2","o2" ,FALSE}
  ,{"Ocean New 2"             ,"oceannew2"  ,"o3" ,FALSE}
  ,{"Ocean New 4"             ,"oceannew4"  ,"o4" ,FALSE}
  ,{"ODEload"                 ,"ode"        ,"od" ,FALSE}
  ,{"Palace F1"               ,"palacef1"   ,"p1" ,FALSE}
  ,{"Palace F2"               ,"palacef2"   ,"p2" ,FALSE}
  ,{"Pavloda"                 ,"pav"        ,"pa" ,FALSE}
  ,{"Rack-It"                 ,"rackit"     ,"ri" ,FALSE}
  ,{"Rainbow Arts F1"         ,"rainbowf1"  ,"r1" ,FALSE}
  ,{"Rainbow Arts F2"         ,"rainbowf2"  ,"r2" ,FALSE}
  ,{"Rasterload"              ,"raster"     ,"rl" ,FALSE}
  ,{"SEUCK"                   ,"seuck"      ,"se" ,FALSE}
  ,{"Smagic 2"                ,"smagic"     ,"sm" ,FALSE}
  ,{"Snakeload 50"            ,"snake50"    ,"sn" ,FALSE}
  ,{"Snakeload 51"            ,"snake51"    ,"s1" ,FALSE}
  ,{"Super Pavloda"           ,"spav"       ,"sp" ,FALSE}
  ,{"Super Tape"              ,"super"      ,"st" ,FALSE}
  ,{"TDI F1"                  ,"tdif1"      ,"td" ,FALSE}
  ,{"TDI F2"                  ,"tdif2"      ,"t2" ,FALSE}
  ,{"Trilogic"                ,"trilogic"   ,"tr" ,FALSE}
  ,{"Turbotape 250"           ,"turbo"      ,"tt" ,FALSE}
  ,{"Turrican"                ,"turr"       ,"tu" ,FALSE}
  ,{"U.S. Gold"               ,"usgold"     ,"us" ,FALSE}
  ,{"Virgin"                  ,"virgin"     ,"vi" ,FALSE}
  ,{"Visiload"                ,"visi"       ,"vl" ,FALSE}
  ,{"Wildload"                ,"wild"       ,"wl" ,FALSE}
  ,{"Your Commodore"          ,"yourcom"    ,"yc" ,FALSE}
  ,{"7bit"                    ,"7bit"       ,"7b" ,FALSE}
};
enum{noc64=0
    ,noaccolade
    ,noaces
    ,noar
    ,noaliensy
    ,noalterwg
    ,noanirog
    ,noashdave
    ,noatlantis
    ,noaudiogenic
    ,nobleep
    ,noburner
    ,noburnervar
    ,nochr
    ,nocult
    ,nocyber
    ,noeasytape
    ,noenigma
    ,nofire
    ,noflash
    ,nofree
    ,nofrslow
    ,noff
    ,nogaladriel
    ,nohit
    ,nohitec
    ,noik
    ,nojet
    ,noloadnrun
    ,nomicro
    ,nonext
    ,nonova
    ,noocean
    ,nooceannew1t1
    ,nooceannew1t2
    ,nooceannew2
    ,nooceannew4
    ,noode
    ,nopalacef1
    ,nopalacef2
    ,nopav
    ,norackit
    ,norainbowf1
    ,norainbowf2
    ,noraster
    ,noseuck
    ,nosmagic
    ,nosnake50
    ,nosnake51
    ,nospav
    ,nosuper
    ,notdif1
    ,notdif2
    ,notrilogic
    ,noturbo
    ,noturr
    ,nousgold
    ,novirgin
    ,novisi
    ,nowild
    ,noyc
    ,no7bit
    };

/*static char loaded        = FALSE;*/

/* Easytape Kludge: TRUE = assume all tape is made with easytape
   and don't recheck for cbmheader
*/
int easykludge  = FALSE;
/* Blackhawk kludge */
int bh_force_easy= 0;
/*
  dirty end of tape? optionally cut it
*/
int cuttrailunrec = FALSE;

static int read_errors[NUM_READ_ERRORS];    /* storage for 1st NUM_READ_ERRORS read error addresses */
static char note_errors;    /* set true only when decoding identified files, */
                /* it just tells 'add_read_error()' to ignore. */

struct tap_t tap;       /* container for the loaded tap (note: only ONE tap). */

int tol = DEFTOL;       /* bit reading tolerance. (1 = zero tolerance) */

int tp_flatten=0; /* iAN: 0=ignore threshold in clean_files(), normal behaviour
                          1=tp->lp
                         -1=tp->sp
                  */
signed char gain=0;/* iAN: add a value to EVERY byte except pauses in load_tap()
                      as an automatic gain (use negative values to subtract) */

char info[INFOSIZE];        /* buffer area for storing each blocks description text. */
                /* also used to store the database report, hence the size! (1MB). */
char lin[LIN_SIZE];     /* general purpose string building buffer. */
char tmp[LIN_SIZE];     /* general purpose string building buffer. */


int aborted = FALSE;        /* general 'operation aborted by user' flag. */

int visi_type = VISI_T2;    /* default visiload type, overidden when loader ID'd. */

int cyber_f2_eor1 = 0xAE;   /* default XOR codes for cyberload f2.. */
int cyber_f2_eor2 = 0xD2;

int batchmode = FALSE;      /* set to 1 when "batch analysis" is performed. */
                /* set to 0 when the user Opens an individual tap. */

unsigned char cbm_header[192];  /* these will allow some interrogation of the CBM parts */
unsigned char cbm_program[65536];   /* that some customized loaders may rely on. (ie. burner). */
int cbm_decoded = FALSE;    /* this ensures only *1st* cbm parts are decoded. */

int quiet = FALSE;      /* set 1 to stop the loader search routines from producing output, */
                /* ie. "Scanning: Freeload". */
                /* i set it (1) when (re)searching during optimization. */

/*int dbase_is_full = 0;*/  /* used by 'addblockdef' to indicate database capacity reached. */

int cps = C64_PAL_CPS;     /* CPU Cycles pr second. Default is C64 PAL */

struct fmt_t ft_org[128];   /* a backup copy of the following... */
struct fmt_t ft[128] = {
        /* name,                 en,   tp,   sp,   mp,  lp,   pv,   sv,  pmin, pmax, has_cs. */
        {""                     ,NA,   NA,   NA,   NA,  NA,   NA,   NA,   NA,  NA,    NA},
        {"UNRECOGNIZED"         ,NA,   NA,   NA,   NA,  NA,   NA,   NA,   NA,  NA,    NA},
        {"PAUSE"                ,NA,   NA,   NA,   NA,  NA,   NA,   NA,   NA,  NA,    NA},
        {"C64 ROM-TAPE HEADER"  ,LSbF, NA,   0x30, 0x42,0x56, NA,   NA,   50,  NA,    CSYES},
        {"C64 ROM-TAPE DATA"    ,LSbF, NA,   0x30, 0x42,0x56, NA,   NA,   50,  NA,    CSYES},
        {"TURBOTAPE-250 HEADER" ,MSbF, 0x20, 0x1A, NA,  0x28, 0x02, 0x09, 50,  NA,    CSNO},
        {"TURBOTAPE-250 DATA"   ,MSbF, 0x20, 0x1A, NA,  0x28, 0x02, 0x09, 50,  NA,    CSYES},
        {"FREELOAD"             ,MSbF, 0x2C, 0x24, NA,  0x42, 0x40, 0x5A, 45,  400,   CSYES},
        {"ODELOAD"              ,MSbF, 0x36, 0x25, NA,  0x50, 0x20, 0xDB, 40,  NA,    CSYES},
        {"CULT"                 ,LSbF, 0x34, 0x27, NA,  0x3E, 0,    1,    1000,NA,    CSNO},
        {"US-GOLD TAPE"         ,MSbF, 0x2C, 0x24, NA,  0x42, 0x20, 0xFF, 50,  NA,    CSYES},
        {"ACE OF ACES TAPE"     ,MSbF, 0x2C, 0x22, NA,  0x47, 0x80, 0xFF, 50,  NA,    CSYES},
        {"WILDLOAD"             ,LSbF, 0x3B, 0x30, NA,  0x47, 0xA0, 0x0A, 50,  NA,    CSYES},
        {"WILDLOAD STOP"        ,LSbF, 0x3B, 0x30, NA,  0x47, 0xA0, 0x0A, 50,  NA,    CSNO},
        {"NOVALOAD"             ,LSbF, 0x3D, 0x24, NA,  0x56, 0,    1,    1800,NA,    CSYES},
        {"NOVALOAD SPECIAL"     ,LSbF, 0x3D, 0x24, NA,  0x56, 0,    1,    1800,NA,    CSYES},
        {"OCEAN/IMAGINE F1"     ,LSbF, 0x3B, 0x24, NA,  0x56, 0,    1,    3000,13000, CSNO},
        {"OCEAN/IMAGINE F2"     ,LSbF, 0x3B, 0x24, NA,  0x56, 0,    1,    3000,13000, CSNO},
        {"OCEAN/IMAGINE F3"     ,LSbF, 0x3B, 0x24, NA,  0x56, 0,    1,    3000,13000, CSNO},
        {"CHR TAPE T1"          ,MSbF, 0x20, 0x1A, NA,  0x28, 0x63, 0x64, 50,  NA,    CSYES},
        {"CHR TAPE T2"          ,MSbF, 0x2D, 0x26, NA,  0x36, 0x63, 0x64, 50,  NA,    CSYES},
        {"CHR TAPE T3"          ,MSbF, 0x3E, 0x36, NA,  0x47, 0x63, 0x64, 50,  NA,    CSYES},
        {"RASTERLOAD"           ,MSbF, 0x3F, 0x26, NA,  0x58, 0x80, 0xFF, 20,  NA,    CSYES},
        {"CYBERLOAD F1"         ,MSbF, VV,   VV,   VV,  VV,   VV,   VV,   50,  NA,    CSNO},
        {"CYBERLOAD F2"         ,MSbF, VV,   VV,   VV,  VV,   VV,   VV,   20,  NA,    CSNO},
        {"CYBERLOAD F3"         ,MSbF, VV,   VV,   VV,  VV,   VV,   VV,    7,   9,    CSYES},
        {"CYBERLOAD F4_1"       ,MSbF, VV,   VV,   VV,  VV,   VV,   VV,    6,  11,    CSYES},
        {"CYBERLOAD F4_2"       ,MSbF, VV,   VV,   VV,  VV,   VV,   VV,    6,  11,    CSYES},
        {"CYBERLOAD F4_3"       ,MSbF, VV,   VV,   VV,  VV,   VV,   VV,    6,  11,    CSYES},
        {"BLEEPLOAD"            ,MSbF, 0x45, 0x30, NA,  0x5A, VV,   VV,   50,  NA,    CSYES},
        {"BLEEPLOAD TRIGGER"    ,MSbF, 0x45, 0x30, NA,  0x5A, VV,   VV,   50,  NA,    CSNO},
        {"BLEEPLOAD SPECIAL"    ,MSbF, 0x45, 0x30, NA,  0x5A, VV,   VV,   50,  NA,    CSYES},
        {"HITLOAD"              ,MSbF, 0x4E, 0x34, NA,  0x66, 0x40, 0x5A, 30,  NA,    CSYES},
        {"MICROLOAD"            ,LSbF, 0x29, 0x1C, NA,  0x36, 0xA0, 0x0A, 50,  NA,    CSYES},
        {"BURNER TAPE"          ,VV,   0x2F, 0x22, NA,  0x42, VV,   VV,   30,  NA,    CSNO},
        {"RACK-IT TAPE"         ,MSbF, 0x2B, 0x1D, NA,  0x3D, VV,   VV,   50,  NA,    CSYES},
        {"SUPERPAV T1 HEADER"   ,MSbF, NA,   0x2E, 0x45,0x5C, NA,   0x66, 50,  NA,    CSYES},
        {"SUPERPAV T1"          ,MSbF, NA,   0x2E, 0x45,0x5C, NA,   0x66, 50,  NA,    CSYES},
        {"SUPERPAV T2 HEADER"   ,MSbF, NA,   0x3E, 0x5D,0x7C, NA,   0x66, 50,  NA,    CSYES},
        {"SUPERPAV T2"          ,MSbF, NA,   0x3E, 0x5D,0x7C, NA,   0x66, 50,  NA,    CSYES},
        {"VIRGIN TAPE"          ,MSbF, 0x2B, 0x21, NA,  0x3B, 0xAA, 0xA0, 30,  NA,    CSYES},
        {"HI-TEC TAPE"          ,MSbF, 0x2F, 0x25, NA,  0x45, 0xAA, 0xA0, 30,  NA,    CSYES},
        {"ANIROG TAPE"          ,MSbF, 0x20, 0x1A, NA,  0x28, 0x02, 0x09, 50,  NA,    CSNO},
        {"VISILOAD T1"          ,VV,   0x35, 0x25, NA,  0x48, 0x00, 0x16, 100, NA,    CSNO},
        {"VISILOAD T2"          ,VV,   0x3B, 0x25, NA,  0x4B, 0x00, 0x16, 100, NA,    CSNO},
        {"VISILOAD T3"          ,VV,   0x3E, 0x25, NA,  0x54, 0x00, 0x16, 100, NA,    CSNO},
        {"VISILOAD T4"          ,VV,   0x47, 0x30, NA,  0x5D, 0x00, 0x16, 100, NA,    CSNO},
        {"SUPERTAPE HEADER"     ,LSbF, NA,   0x21, 0x32,0x43, 0x16, 0x2A, 50,  NA,    CSYES},
        {"SUPERTAPE DATA"       ,LSbF, NA,   0x21, 0x32,0x43, 0x16, 0xC5, 50,  NA,    CSYES},
        {"PAVLODA"              ,MSbF, 0x28, 0x1F, NA,  0x3F, 0,    1,    50,  NA,    CSYES},
        {"IK TAPE"              ,MSbF, 0x2C, 0x27, NA,  0x3F, 1,    0,    1000,NA,    CSYES},
        {"FIREBIRD T1"          ,LSbF, 0x62, 0x44, NA,  0x7E, 0x02, 0x52, 30,  NA,    CSYES},
        {"FIREBIRD T2"          ,LSbF, 0x52, 0x45, NA,  0x65, 0x02, 0x52, 30,  NA,    CSYES},
        {"TURRICAN TAPE HEADER" ,MSbF, NA,   0x1B, NA,  0x27, 0x02, 0x0C, 30,  NA,    CSNO},
        {"TURRICAN TAPE DATA"   ,MSbF, NA,   0x1B, NA,  0x27, 0x02, 0x0C, 30,  NA,    CSYES},
        {"SEUCK LOADER 2"       ,LSbF, 0x2D, 0x20, NA,  0x41, 0xE3, 0xD5, 5,   NA,    CSYES},
        {"SEUCK HEADER"         ,LSbF, 0x2D, 0x20, NA,  0x41, 0xE3, 0xD5, 5,   NA,    CSNO},
        {"SEUCK SUB-BLOCK"      ,LSbF, 0x2D, 0x20, NA,  0x41, 0xE3, 0xD5, 5,   NA,    CSYES},
        {"SEUCK TRIGGER"        ,LSbF, 0x2D, 0x20, NA,  0x41, 0xE3, 0xD5, 5,   NA,    CSNO},
        {"SEUCK GAME"           ,LSbF, 0x2D, 0x20, NA,  0x41, 0xE3, 0xAC, 50,  NA,    CSNO},
        {"JETLOAD"              ,LSbF, 0x3B, 0x33, NA,  0x58, 0xD1, 0x2E, 1,   NA,    CSNO},
        {"FLASHLOAD"            ,MSbF, NA,   0x1F, NA,  0x31, 1,    0,    50,  NA,    CSYES},
        {"TDI TAPE F1"          ,LSbF, NA,   0x44, NA,  0x65, 0xA0, 0x0A, 50,  NA,    CSYES},
        {"OCEAN NEW TAPE F1 T1" ,MSbF, NA,   0x22, NA,  0x42, 0x40, 0x5A, 50,  200,   CSYES},
        {"OCEAN NEW TAPE F1 T2" ,MSbF, NA,   0x35, NA,  0x65, 0x40, 0x5A, 50,  200,   CSYES},
        {"OCEAN NEW TAPE F2"    ,MSbF, 0x2C, 0x22, NA,  0x42, 0x40, 0x5A, 50,  200,   CSYES},
        {"ATLANTIS TAPE"        ,LSbF, 0x2F, 0x1D, NA,  0x42, 0x02, 0x52, 50,  NA,    CSYES},
        {"SNAKELOAD 5.1"        ,MSbF, NA,   0x28, NA,  0x48, 0,    1,    1800,NA,    CSYES},
        {"SNAKELOAD 5.0 T1"     ,MSbF, NA,   0x3F, NA,  0x5F, 0,    1,    1800,NA,    CSYES},
        {"SNAKELOAD 5.0 T2"     ,MSbF, NA,   0x60, NA,  0xA0, 0,    1,    1800,NA,    CSYES},
        {"PALACE TAPE F1"       ,MSbF, NA,   0x30, NA,  0x57, 0x01, 0x4A, 50,  NA,    CSYES},
        {"PALACE TAPE F2"       ,MSbF, NA,   0x30, NA,  0x57, 0x01, 0x4A, 50,  NA,    CSYES},
        {"ENIGMA TAPE"          ,MSbF, 0x2C, 0x24, NA,  0x42, 0x40, 0x5A, 700, NA,    CSNO},
        {"AUDIOGENIC"           ,MSbF, 0x28, 0x1A, NA,  0x36, 0xF0, 0xAA, 4,   NA,    CSYES},
        {"ALIEN SYNDROME"       ,MSbF, 0x2C, 0x20, NA,  0x43, 0xE3, 0xED, 4,   NA,    CSYES},
        {"ACCOLADE"             ,MSbF, 0x3D, 0x29, NA,  0x4A, 0x0F, 0xAA, 4,   NA,    CSYES},
        {"ALTERNATIVE WORLD G." ,MSbF, 0x4A, 0x33, NA,  0x65, 0x01, 0x00, 192, NA,    CSNO},
        {"RAINBOW ARTS F1"      ,LSbF, 0x2A, 0x19, NA,  0x36, 0xA0, 0x0A, 800, NA,    CSYES},
        {"RAINBOW ARTS F2"      ,LSbF, 0x2A, 0x19, NA,  0x36, 0xA0, 0x0A, 800, NA,    CSYES},
        {"TRILOGIC"             ,MSbF, 0x28, 0x1C, NA,  0x35, 0x0F, 0x0E, 200, NA,    CSYES},
        {"BURNER VARIANT"       ,VV,   0x30, 0x23, NA,  0x42, VV,   VV,   50,  NA,    CSNO},
        {"OCEAN NEW TAPE F4"    ,MSbF, 0x2D, 0x24, NA,  0x44, 0x40, 0x5A, 50,  200,   CSYES},
        {"TDI TAPE F2"          ,LSbF, NA,   0x44, NA,  0x65, 0xA0, 0x0A, 50,  NA,    CSYES},
        {"GALADRIEL"            ,MSbF, 0x20, 0x1b, NA,  0x27, 0x02, 0x10, 50,  NA,    CSNO },
        {"GALADRIEL_XOR"        ,MSbF, 0x20, 0x1b, NA,  0x27, 0x02, 0x10, 50,  NA,    CSNO },
        {"GALADRIEL_BOB85"      ,MSbF, 0x20, 0x1b, NA,  0x27, 0x02, 0x10, 50,  NA,    CSNO},
        {"GALADRIEL_POKE"       ,MSbF, 0x20, 0x1b, NA,  0x27, 0x02, 0x09, 50,  NA,    CSNO},
        {"GALADRIEL_POKE1"      ,MSbF, 0x20, 0x1b, NA,  0x27, 0x01, 0x09, 50,  NA,    CSNO},
        {"GALADRIEL_REV"        ,LSbF, 0x20, 0x1b, NA,  0x39, 0x02, 0x09, 50,  NA,    CSYES},
        {"EASYTAPE1"            ,LSbF, 0x2F, 0x1D, NA,  0x42, 0x02, 0x52, 50,  NA,    CSYES},
        {"EASYTAPE2"            ,LSbF, 0x2F, 0x1D, NA,  0x42, 0x02, 0x52, 50,  NA,    CSYES},
        {"ACTIONREPLAY"         ,LSbF, 0x3b, 0x23, NA,  0x53, 0x7f, 0x52,  1,  NA,    CSYES},
        {"ACTIONREPLAY_SUPER"   ,LSbF, 0x1f, 0x13, NA,  0x2b, 0x7f, 0x52,  1,  NA,    CSYES},
        {"ACTIONREPLAY_HEADER"  ,LSbF, 0x3b, 0x23, NA,  0x53, 0x7f, 0x52,  1,  NA,    CSNO},
        {"ATOMICPOWER"          ,LSbF, 0x3b, 0x23, NA,  0x53, 0x7f, 0x52,  1,  NA,    CSYES},
        {"SMAGIC2"              ,MSbF, 0x1e, 0x16, NA,  0x27, 0x40, 0x40, 50,  NA,    CSYES},
        {"NEXT HEADER"          ,MSbF, 0x41, 0x3b, NA,  0x48, 0x02, 0x09, 50,  NA,    CSNO},
        {"NEXT DATA"            ,MSbF, 0x41, 0x3b, NA,  0x48, 0x02, 0x09, 50,  NA,    CSYES},
        {"LOAD'N'RUN HEADER"    ,MSbF, 0x3d, 0x32, NA,  0x4b, 0x02, 0x09, 50,  NA,    CSNO},
        {"LOAD'N'RUN DATA"      ,MSbF, 0x3d, 0x32, NA,  0x4b, 0x02, 0x09, 50,  NA,    CSYES},
        {"7NOTE BIT HEADER"     ,MSbF, 0x36, 0x29, NA,  0x43, 0x02, 0x09, 50,  NA,    CSNO},
        {"7NOTE BIT DATA"       ,MSbF, 0x36, 0x29, NA,  0x43, 0x02, 0x09, 50,  NA,    CSYES},
        {"FREEZEFRAME"          ,LSbF, 0x34, 0x28, NA,  0x3f, 0x00, 0x80,  0, 100,    CSNO},
        {"ASH AND DAVE"         ,MSbF, 0x2D, 0x22, NA,  0x44, 0x80, 0x40, 200, NA,    CSNO},
        {"FREELOAD SLOWLOAD"    ,MSbF, 0x77, 0x5A, NA,  0x85, 0x40, 0x5A, 45,  400,   CSYES},
        {"YOUR COMMODORE"       ,MSbF, 0x1e, 0x16, NA,  0x27, 0x40, 0x40, 50,  NA,    CSYES},
        {""                     ,666,   666,  666,666,   666,  666,  666,666, 666,    666}
        /* name,                 en,   tp,   sp,   mp,  lp,   pv,   sv,  pmin, pmax, has_cs. */
};
/* where a field is marked 'VV', loader/file interrogation is required to
 * discover the missing value.
 * NOTE: some of the values (like number of pilot bytes) may not agree with
 * the loader docs, this is done to let partly damaged games be detected
 * and fixed.
 *
 * en = byte endianess, 0=LSbF, 1=MSbF
 * tp = threshold pulsewidth (if applicable)
 * sp = ideal short pulsewidth
 * mp = ideal medium pulsewidth (if applicable)
 * lp = ideal long pulsewidth
 * pv = pilot value
 * sv = sync value
 * pmin = minimum pilots that should be present.
 * pmax = maximum pilots that should be present.
 * has_cs = flag, provides checksums, 1=yes, 0=no.
 */



/* The following strings are used by the loader ID system...
 *   see enum for this table in mydefs.h...
 */

const char knam[128][32] = {
    {"n/a"},
    {"Freeload (or clone)"},
    {"Odeload"},
    {"Bleepload"},
    {"CHR loader"},
    {"Burner"},
    {"Wildload"},
    {"US Gold loader"},
    {"Microload"},
    {"Ace of Aces loader"},
    {"Turbotape 250"},
    {"Rack-It loader"},
    {"Ocean/Imagine (ns)"},
    {"Rasterload"},
    {"Super Pavloda"},
    {"Hit-Load"},
    {"Anirog loader"},
    {"Visiload T1"},
    {"Visiload T2"},
    {"Visiload T3"},
    {"Visiload T4"},
    {"Firebird loader"},
    {"Novaload (ns)"},
    {"IK loader"},
    {"Pavloda"},
    {"Cyberload"},
    {"Virgin"},
    {"Hi-Tec"},
    {"Flashload"},
    {"Supertape"},
    {"Ocean New 1 T1"},
    {"Ocean New 1 T2"},
    {"Atlantis Loader"},
    {"Snakeload"},
    {"Ocean New 2"},
    {"Audiogenic"},
    {"Cult tape"},
    {"Accolade (or clone)"},
    {"Rainbow Arts (F1/F2)"},
    {"Burner (Mastertronic Variant)"},
    {"Ocean New 4"},
    {"Your Commdore"},
    {"Freeload Slowload"}
    /*{"Galadriel"},    */
    /*{"Easytape"},     */
    /*{"ActionReplay"}, */
    /*{"Smagic2"}, */
    /*{"Load'N'Run"}, */
    /*{"Next1"}, */
    /*{"FreezeFrame"}   */
};

/* note: all generated files are saved to the exedir */

/*static const*/ char tcreportname[MAXPATH] =   "tcreport.txt";
static const char temptcreportname[] =  "tcreport.tmp";
static const char tcinfoname[] =    "tcinfo.txt";
char *MSGBLANK="\r                                        \r";
static char cleanedtapname[MAXPATH];    /* assigned in main(). */

const char tcbatchreportname[] =    "tcbatch.txt";
const char temptcbatchreportname[] =    "tcbatch.tmp";
char exedir[MAXPATH];           /* global, assigned in main(), includes trailing slash. */
char prgdir[MAXPATH]="prg"; /* iAN: instead of simply "prg" one dir for each tape */
int useprgdir=0; /* 0="prg", 1="prg"+tap.name */

/**
 *  Internal usage functions
 */

/*
 * Erase all stored data for the loaded 'tap', free buffers,
 * and reset database entries.
 */

static void unload_tap(void)
{
    int i;

    strcpy(tap.path, "");
    strcpy(tap.name, "");
    strcpy(tap.cbmname, "");
    if(tap.tmem != NULL) {
        free(tap.tmem);
        tap.tmem = NULL;
    }

    tap.len = 0;
    for(i = 0; i < 256; i++) {
        tap.pst[i] = 0;
        tap.fst[i] = 0;
    }

    tap.fsigcheck = 0;
    tap.fvercheck = 0;
    tap.fsizcheck = 0;
    tap.detected = 0;
    tap.detected_percent = 0;
    tap.purity = 0;
    tap.total_gaps = 0;
    tap.total_data_files = 0;
    tap.total_checksums = 0;
    tap.total_checksums_good = 0;
    tap.optimized_files = 0;
    tap.total_read_errors = 0;
    tap.fdate = 0;
    tap.taptime = 0;
    tap.version = 0;
    tap.bootable = 0;
    tap.changed = 0;
    tap.crc = 0;
    tap.cbmcrc = 0;
    tap.cbmid = 0;
    tap.tst_hd = 0;
    tap.tst_rc = 0;
    tap.tst_op = 0;
    tap.tst_cs = 0;
    tap.tst_rd = 0;

    reset_database();
    reset_prg_database();
}

/*
 * Unallocate tap, crc_table and database
 */

static void cleanup_main(void)
{
    unload_tap();
    free_crc_table();

    /* deallocate ram from file database */
    destroy_database();
}

/*
 * Get exe path from argv[0]...
 */

static int get_exedir(char *argv0)
{
    char *ret;

#ifdef WIN32
    /* First check if argv0 fits inside our buffer */
#if 0
    if (strlen(argv0) > MAXPATH - 1)
        return FALSE;

    /* It's now safe to copy inside the buffer (padding with nulls!) */
    strncpy(exedir, argv0, MAXPATH);

    /* When run at the console argv[0] is simply "tapclean" or "tapclean.exe" */

    /* Note: we do this instead of using getcwd() because getcwd does not give
     * the exe's directory when dragging and dropping a tap file to the program
     * icon using windows explorer.
     */
    if (stricmp(exedir, "tapclean") != 0 && stricmp(exedir, "tapclean.exe") != 0) {
        int i;

        /* Clip to leave path only */
        for (i = strlen(exedir) - 1; i > 0 && exedir[i] != SLASH; i--)
            ;

        if (exedir[i] == SLASH)
            exedir[i + 1] = '\0';

        return TRUE;
    }
#endif
    /* iAN: I want everything created in the current dir, not in the exe dir (WTF?) */
    GetCurrentDirectory(MAXPATH,exedir);
#endif

    ret = (char *)getcwd(exedir, MAXPATH - 2);
    if (ret == NULL)
        return FALSE;

    exedir[strlen(exedir)] = SLASH;
    exedir[strlen(exedir)] = '\0';

    return TRUE;
}

/*
 * make a copy of the loader table ft[] so we can revert back to it after any changes.
 * the copy is globally available in ft_org[]
 */

static void copy_loader_table(void)
{
    int i;

    for (i = 0; ft[i].tp != 666; i++) {
        strcpy(ft_org[i].name, ft[i].name);
        ft_org[i].en = ft[i].en;
        ft_org[i].tp = ft[i].tp;
        ft_org[i].sp = ft[i].sp;
        ft_org[i].mp = ft[i].mp;
        ft_org[i].lp = ft[i].lp;
        ft_org[i].pv = ft[i].pv;
        ft_org[i].sv = ft[i].sv;
        ft_org[i].pmin = ft[i].pmin;
        ft_org[i].pmax = ft[i].pmax;
        ft_org[i].has_cs = ft[i].has_cs;
    }
}

/*
 * reset loader table to all original values, ONLY call this if a call to
 * copy_loader_table() has been made.
 */

static void reset_loader_table(void)
{
    int i;

    for (i = 0; ft[i].tp != 666; i++) {
        strcpy(ft[i].name, ft_org[i].name);
        ft[i].en = ft_org[i].en;
        ft[i].tp = ft_org[i].tp;
        ft[i].sp = ft_org[i].sp;
        ft[i].mp = ft_org[i].mp;
        ft[i].lp = ft_org[i].lp;
        ft[i].pv = ft_org[i].pv;
        ft[i].sv = ft_org[i].sv;
        ft[i].pmin = ft_org[i].pmin;
        ft[i].pmax = ft_org[i].pmax;
        ft[i].has_cs = ft_org[i].has_cs;
    }
}

/*
 * Display usage
 */

static void display_usage(void)
{
    printf(
           "\nUsage:\n"
           "tapclean [[option][parameter]]...\n"
           "example: tapclean -o giana_sisters.tap -tol 12\n\n"
           "options...\n\n"
           " -t   [tap]         Test TAP.\n"
           " -o   [tap]         Optimize TAP.\n"
           " -b   [dir]         Batch test.\n"
           " -au  [tap]         Convert TAP to Sun AU audio file (44kHz).\n"
           " -wav [tap]         Convert TAP to Microsoft WAV audio file (44kHz).\n"
           " -rs  [tap]         Corrects the 'size' field of a TAPs header.\n"
           " -ct0 [tap]         Convert TAP to version 0 format.\n"
           " -ct1 [tap]         Convert TAP to version 1 format.\n"
           " -16                Commodore 16 tape.\n"
           " -20                Commodore VIC 20 tape.\n"
           " -64                Commodore 64 tape (default).\n"
           " -boostclean   -bc  Raise cleaning threshold.\n"
           " -debug        -D   Allows detected files to overlap.\n"
           " -docyberfault -c   Report Cyberload F3 bad checksums of $04.\n"
           " -doprg        -p   Create PRG files.\n"
           " -prgdir       -d   Create PRG_tapname\\ directory instead of PRG\\\n"
           " -extvisipatch -xv  Extract Visiload loader patch files.\n"
           " -ec                Export CyberLoaders\n"
           " -incsubdirs   -s   Make batch scan include subdirectories.\n"
           " -noaddpause   -P   Dont add a pause to the file end after clean.\n"
           " -noc64eof     -e   C64 ROM scanner will not expect EOF markers.\n"
           " -noid         -ni  Disable scanning for only the 1st ID'd loader.\n"
           " -no<loader>        Don't scan for this loader. Example: -nocyber.\n"
           " -noall        -n   Don't scan for any loader except for CBM headers.\n"
           " -do<loader>        Scan only for this loader, to use after -noall.\n"
           " -easykludge   -ek  Assume all tape is made with Easytape (-noall -doeasytape)\n"
           " -list         -l   List of supported scanners and options used by -no<loader>\n"
           " -ntsc              NTSC timing.\n"
           " -pal               PAL timing (default).\n"
           " -prgunite     -u   Connect neighbouring PRG's into a single file.\n"
           " -removetrail  -r   Remove trailing dirty/unrecognized block.\n"
           " -sine         -z   Make audio converter use sine waves.\n"
           " -sortbycrc    -C   Batch scan sorts report by cbmcrc values.\n"
           " -tol [0-%02d]   -T   Set pulsewidth read tolerance, default = %02d.\n"
           " -tp (s/l)          Threshold treated as (s)hort/(l)ong, default = ignored\n"
           " -gain N       -g   Add a gain value to every byte read from tap (-16/+16)\n"
           ,MAXTOL-1,DEFTOL-1
        );

}

/*
 * Display scanner list
 */

static void display_scanners(void)
{
    int i,l;
    printf("\nList of supported scanners and their -no<loader>/-do<loader> parameter names.\n\n");
    l=sizeof(ldrswt)/sizeof(*ldrswt);
    for(i=0;i<l;i++)
    printf(" %-24s | -no%-12s(-no%2s) | -do%-12s(-do%2s)\n",ldrswt[i].desc,ldrswt[i].par,ldrswt[i].shortpar,ldrswt[i].par,ldrswt[i].shortpar );
}

/* noall */
static void set_noall(void)
{
    int i,l;
    l=sizeof(ldrswt)/sizeof(*ldrswt);
    ldrswt[0].state = FALSE;
    for(i=1;i<l;i++)
    ldrswt[i].state = TRUE;
}

/*
 * Process options
 */

static void process_options(int argc, char **argv)
{
    int i;
    int excludeflag = 1;
    int jj,sl;
    sl=sizeof(ldrswt)/sizeof(*ldrswt);

    for (i = 0; i < argc; i++) {
        if((strcmp(argv[i], "-tol") == 0)||
           (strcmp(argv[i], "-T"  ) == 0) )
        {             /* flag = set tolerance */
            if (argv[i + 1] != NULL) {
                tol = atoi(argv[i + 1]) + 1;    /* 1 = zero tolerance (-tol 0) */
                if (tol < 0 || tol > MAXTOL) {
                    tol = DEFTOL;
                    printf("\n\nTolerance parameter out of range, using default (= 10).");
                }
            } else
                printf("\n\nTolerance parameter missing, using default (= 10).");
            continue;
        }
        if (strcmp(argv[i], "-tp") == 0)
        {
            if (argv[i + 1] != NULL)
            {
                char *tpdesc[]= {"Short"
                                ,"Ignored"
                                ,"Long"
                                };
                if(((argv[i + 1][0])&0xdf)=='S')
                    tp_flatten=-1;
                else if(((argv[i + 1][0])&0xdf)=='L')
                    tp_flatten=1;
                else
                { /* alt subparam: -1/1/0 */
                    tp_flatten=atoi(argv[i + 1]);
                    if(tp_flatten<0) tp_flatten=-1;
                    if(tp_flatten>0) tp_flatten=1;
                }
                printf( "\nThreshold = %s\n",tpdesc[tp_flatten+1]);
            }
            continue;
        }

        if((strcmp(argv[i], "-gain") == 0)||
           (strcmp(argv[i], "-g"   ) == 0) )
        {
            if (argv[i + 1] != NULL)
            {
            	gain = strtol(argv[i + 1],NULL,10);
                if(gain>16||gain<-16)
                	gain=0;
                if(gain)
                   printf( "\nGain = %d\n",gain);
            }
        }
        if((strcmp(argv[i], "-debug") == 0)||
           (strcmp(argv[i], "-D"    ) == 0) )
        {
           debug = TRUE;
           continue;
        }
        if((strcmp(argv[i], "-noid") == 0)||
           (strcmp(argv[i], "-ni"  ) == 0) )
        {
            noid = TRUE;
            continue;
        }
        if (strcmp(argv[i], "-16") == 0)
        {
            c16 = TRUE;
            c64 = FALSE;
            c20 = FALSE;
            continue;
        }
        if (strcmp(argv[i], "-20") == 0)
        {
            c16 = FALSE;
            c64 = FALSE;
            c20 = TRUE;
            continue;
        }
        if (strcmp(argv[i], "-64") == 0)
        {
            c16 = FALSE;
            c64 = TRUE;
            c20 = FALSE;
            continue;
        }
        if (strcmp(argv[i], "-pal") == 0)
        {
            ntsc = FALSE;
            pal  = TRUE;
            continue;
        }
        if (strcmp(argv[i], "-ntsc") == 0)
        {
            ntsc = TRUE;
            pal  = FALSE;
            continue;
        }
        if((strcmp(argv[i], "-noc64eof") == 0)||
           (strcmp(argv[i], "-e"       ) == 0) )
        {
            noc64eof = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-docyberfault") == 0)||
           (strcmp(argv[i], "-c"           ) == 0) )
        {
            docyberfault = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-boostclean") == 0)||
           (strcmp(argv[i], "-bc"        ) == 0) )
        {
            boostclean = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-noaddpause") == 0)||
           (strcmp(argv[i], "-P"         ) == 0) )
        {
            noaddpause = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-sine") == 0)||
           (strcmp(argv[i], "-z"   ) == 0) )
        {
            sine = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-prgunite") == 0)||
           (strcmp(argv[i], "-u"       ) == 0) )
        {
            prgunite = TRUE;
            doprg = TRUE;
            continue;
        }

        if((strcmp(argv[i], "-doprg") == 0)||
           (strcmp(argv[i], "-p"    ) == 0) )
        {
            doprg = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-extvisipatch") == 0)||
           (strcmp(argv[i], "-xv"          ) == 0) )
        {
            extvisipatch = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-incsubdirs") == 0)||
           (strcmp(argv[i], "-s"         ) == 0) )
        {
            incsubdirs = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-list") == 0)||
           (strcmp(argv[i], "-l"   ) == 0) )
        {
            display_scanners();
            exit(0);
        }

        if((strcmp(argv[i], "-removetrail") == 0)||
           (strcmp(argv[i], "-r"        ) == 0) )
        {
            cuttrailunrec = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-sortbycrc") == 0)||
           (strcmp(argv[i], "-C"        ) == 0) )
        {
            sortbycrc = TRUE;
            continue;
        }
        if (strcmp(argv[i], "-ec") == 0)
        {
            exportcyberloaders = TRUE;
            continue;
        }
        if((strcmp(argv[i], "-prgdir") == 0)||
           (strcmp(argv[i], "-d"     ) == 0) )
        {
            useprgdir=1;
            continue;
        }
        /* process all -no<loader> */
        if (strncmp(argv[i], "-no", 3) == 0)
        {
            if (excludeflag == 1)
            {
                printf("\nExcluded scanners:\n\n");
                excludeflag = 0;
            }

            for(jj=0;jj<sl;jj++)
            {
                if((strcmp(argv[i]+3, ldrswt[jj].par     ) ==  0)||
                   (strcmp(argv[i]+3, ldrswt[jj].shortpar) ==  0) )
                {
                    ldrswt[jj].state = TRUE;
                    printf(" %s\n",ldrswt[jj].desc);
                }
            }
        }

        /* disable all scanners exc 'c64 rom tape' */

        if( (strcmp(argv[i], "-noall") == 0)||
            (strcmp(argv[i], "-n"    ) == 0) )
        {
            set_noall();
            if (excludeflag == 1)
            {
                printf("\nExcluded scanners:\n\n");
                excludeflag = 0;
            }
            printf(" All except C64 ROM scanner\n");
            continue;
        }

        /* process all -do<loader> */

        if (strncmp(argv[i], "-do", 3) == 0 && excludeflag==0)
        {
            for(jj=0;jj<sl;jj++)
            {
                if((strcmp(argv[i]+3, ldrswt[jj].par     ) ==  0)||
                   (strcmp(argv[i]+3, ldrswt[jj].shortpar) ==  0) )
                {
                    ldrswt[jj].state = FALSE;
                    printf(" +%s\n",ldrswt[jj].desc);
                    break;
                }
            }
            continue;
        }

        if((strcmp(argv[i], "-easykludge") == 0)||
           (strcmp(argv[i], "-ek"        ) == 0) )
        {
            set_noall();
            ldrswt[noeasytape].state = FALSE;
            easykludge = TRUE ;
            printf("\nExcluded scanners:\n\n");
            printf(" All except c64 ROM scanner\n");
            printf(" +Easytape(forced)\n");
        }
    }

    printf("\n\nRead tolerance = %d", tol - 1);
}

/*
 * Choose CPU cycles based on computer type and PAL/NTSC
 */

static void handle_cps(void)
{
    printf("\n\nComputer type: ");

    if (c64 == TRUE) {
        printf("C64 ");
        if (pal == TRUE)
            cps = C64_PAL_CPS;
        else
            cps = C64_NTSC_CPS;
    } else if (c16 == TRUE) {
        printf("C16 ");
        /* Force CBM pulsewidths to the ones found in C16/+4 tapes */
        /* iAN : no need to set pulses here, they depends on tap version byte */
        if (pal == TRUE)
            cps = C16_PAL_CPS;
        else
            cps = C16_NTSC_CPS;
    } else if (c20 == TRUE) {
        printf("VIC20 ");
        /* Force CBM pulsewidths to the ones found in VIC20 tapes */
        /*
        ft [CBM_HEAD].sp = 0x2B;
        ft [CBM_HEAD].mp = 0x3F;
        ft [CBM_HEAD].lp = 0x53;

        ft [CBM_DATA].sp = 0x2B;
        ft [CBM_DATA].mp = 0x3F;
        ft [CBM_DATA].lp = 0x53;
        */
        /* iAN : I found these values more correct */
        ft [CBM_HEAD].sp = 0x2A;
        ft [CBM_HEAD].mp = 0x39;
        ft [CBM_HEAD].lp = 0x4A;

        ft [CBM_DATA].sp = 0x2A;
        ft [CBM_DATA].mp = 0x39;
        ft [CBM_DATA].lp = 0x4A;
        if (pal == TRUE)
            cps = VIC20_PAL_CPS;
        else
            cps = VIC20_NTSC_CPS;
    }

    if (pal == TRUE)
        printf("PAL ");
    else
        printf("NTSC ");

    printf("(%d Hz)\n", cps);
}

/*
 * Search the tap for all known (and enabled) file formats.
 *
 * Results are stored in the 'blk' database (an array of structs).
 *
 * If global variable 'quiet' is set (1), the scanners will not print a
 * "Scanning: xxxxxxx" string. This simply reduces text output and I prefer this
 * when optimizing (Search is called quite frequently).
 *
 * Note: This function calls all 'loadername_search' routines and as a result it
 *   fills out only about half of the fields in the blk[] database, they are...
 *
 *   lt, p1, p2, p3, p4, xi (ie, all fields supported by 'addblockdef()').
 *
 *   the remaining fields (below) are filled out by 'describe_blocks()' which
 *   calls all 'loadername_decribe()' routines for the particular format (lt).
 *
 *   cs, ce, cx, rd_err, crc, cs_exp, cs_act, pilot_len, trail_len, ok.
 */

static void search_tap(void)
{
    int i;

    dbase_is_full = FALSE;  /* enable the "database full" warning. */
                /* note: addblockdef sets it 1 when full. */

    msgout("\nScanning...");

    if (tap.changed) {
        reset_database();

        /* initialize the read error table */

        for (i = 0; i < NUM_READ_ERRORS; i++)
            read_errors[i] = 0;


        /* CALL THE SCANNERS!... */

        pause_search();     /* pauses and CBM files always get searched for...  */
        cbm_search();

        /* Note : if cbm parts are found then this call (cbm_search) will create copies
         * of the header and data parts in 'cbm_header[]' and 'cbm_program[]'.
         * Also a crc32 of the data block is recorded in 'tap.cbmcrc'.
         */

        /* try and id any loader stored in cbm_program[]... */

        tap.cbmid = idloader(tap.cbmcrc);

        if (!quiet) {
            sprintf(lin, "\n  Loader ID: %s.\n", knam[tap.cbmid]);
            msgout(lin);
        }

        if (noid == FALSE) {    /* scanning shortcuts enabled?  */
            if (tap.cbmid == LID_T250   && ldrswt[noturbo].state == FALSE && !dbase_is_full && !aborted)
                turbotape_search(TT_HEAD);

            if (tap.cbmid == LID_FREE   && ldrswt[nofree ].state== FALSE && !dbase_is_full && !aborted)
                freeload_search();

            if (tap.cbmid == LID_ODE    && ldrswt[noode ].state== FALSE && !dbase_is_full && !aborted)
                odeload_search();

            if (tap.cbmid == LID_NOVA   && ldrswt[nonova ].state== FALSE && !dbase_is_full && !aborted) {
                nova_spc_search();
                nova_search();
            }

            if (tap.cbmid == LID_BLEEP  && ldrswt[nobleep].state == FALSE && !dbase_is_full && !aborted) {
                bleep_search();
                bleep_spc_search();
            }

            if (tap.cbmid == LID_OCEAN  && ldrswt[noocean].state == FALSE && !dbase_is_full && !aborted)
                ocean_search();

            if (tap.cbmid == LID_CYBER  && ldrswt[nocyber].state == FALSE &&!dbase_is_full) {
                cyberload_f1_search();
                cyberload_f2_search();
                cyberload_f3_search();
                cyberload_f4_search();
            }

            if (tap.cbmid == LID_USG    && ldrswt[nousgold  ].state == FALSE && !dbase_is_full && !aborted)
                usgold_search();

            if (tap.cbmid == LID_ACE    && ldrswt[noaces    ].state == FALSE && !dbase_is_full && !aborted)
                aces_search();

            if (tap.cbmid == LID_MIC    && ldrswt[nomicro   ].state == FALSE && !dbase_is_full && !aborted)
                micro_search();

            if (tap.cbmid == LID_RAST   && ldrswt[noraster  ].state == FALSE && !dbase_is_full && !aborted)
                raster_search();

            if (tap.cbmid == LID_CHR    && ldrswt[nochr     ].state == FALSE && !dbase_is_full)
                chr_search();

            if (tap.cbmid == LID_BURN   && ldrswt[noburner  ].state == FALSE && !dbase_is_full && !aborted)
                burner_search();

            /* if it's a visiload then choose correct type now... */

            if (tap.cbmid == LID_VIS1)
                visi_type = VISI_T1;

            if (tap.cbmid == LID_VIS2)
                visi_type = VISI_T2;

            if (tap.cbmid == LID_VIS3)
                visi_type = VISI_T3;

            if (tap.cbmid == LID_VIS4)
                visi_type = VISI_T4;

            if (tap.cbmid == LID_VIS1 || tap.cbmid == LID_VIS2 || tap.cbmid == LID_VIS3 || tap.cbmid == LID_VIS4) {
                if (ldrswt[novisi].state == FALSE && !dbase_is_full && !aborted)
                    visiload_search();
            }

            if (tap.cbmid == LID_WILD   && ldrswt[nowild    ].state == FALSE && !dbase_is_full && !aborted)
                wild_search();

            if (tap.cbmid == LID_HIT    && ldrswt[nohit     ].state == FALSE && !dbase_is_full && !aborted)
                hitload_search();

            if (tap.cbmid == LID_RACK   && ldrswt[norackit  ].state == FALSE && !dbase_is_full && !aborted)
                rackit_search();

            if (tap.cbmid == LID_SPAV   && ldrswt[nospav    ].state == FALSE && !dbase_is_full && !aborted)
                superpav_search();

            if (tap.cbmid == LID_ANI    && ldrswt[noanirog  ].state == FALSE && !dbase_is_full && !aborted) {
                anirog_search();
                freeload_search();
            }

            if (tap.cbmid == LID_SUPER  && ldrswt[nosuper   ].state == FALSE && !dbase_is_full && !aborted)
                supertape_search();

            if (tap.cbmid == LID_FIRE   && ldrswt[nofire    ].state == FALSE && !dbase_is_full && !aborted)
                firebird_search();

            if (tap.cbmid == LID_PAV    && ldrswt[nopav     ].state == FALSE && !dbase_is_full && !aborted)
                pav_search();

            if (tap.cbmid == LID_IK     && ldrswt[noik      ].state == FALSE && !dbase_is_full && !aborted)
                ik_search();

            if (tap.cbmid == LID_FLASH  && ldrswt[noflash   ].state == FALSE && !dbase_is_full && !aborted)
                flashload_search();

            if (tap.cbmid == LID_VIRG   && ldrswt[novirgin  ].state == FALSE && !dbase_is_full && !aborted)
                virgin_search();

            if (tap.cbmid == LID_HTEC   && ldrswt[nohitec   ].state == FALSE && !dbase_is_full && !aborted)
                hitec_search();

            if (tap.cbmid == LID_OCNEW1T1 && ldrswt[nooceannew1t1].state == FALSE && !dbase_is_full && !aborted)
                oceannew1t1_search();

            if (tap.cbmid == LID_OCNEW1T2 && ldrswt[nooceannew1t2].state == FALSE && !dbase_is_full && !aborted)
                oceannew1t2_search();

            if (tap.cbmid == LID_OCNEW2   && ldrswt[nooceannew2].state == FALSE && !dbase_is_full && !aborted)
                oceannew2_search();

            if (tap.cbmid == LID_SNAKE  && ldrswt[nosnake50].state == FALSE && !dbase_is_full && !aborted) {
                snakeload50t1_search();
                snakeload50t2_search();
            }

            if (tap.cbmid == LID_SNAKE      && ldrswt[nosnake51     ].state == FALSE && !dbase_is_full && !aborted)
                snakeload51_search();

            if (tap.cbmid == LID_ATLAN      && ldrswt[noatlantis    ].state == FALSE && !dbase_is_full && !aborted)
                atlantis_search();

            if (tap.cbmid == LID_AUDIOGENIC && ldrswt[noaudiogenic  ].state == FALSE && !dbase_is_full && !aborted)
                audiogenic_search();

            if (tap.cbmid == LID_CULT       && ldrswt[nocult        ].state == FALSE && !dbase_is_full && !aborted)
                cult_search();

            if (tap.cbmid == LID_ACCOLADE       && ldrswt[noaccolade].state == FALSE && !dbase_is_full && !aborted)
                accolade_search();

            if (tap.cbmid == LID_RAINBOWARTS    && ldrswt[norainbowf1].state == FALSE && !dbase_is_full && !aborted)
                rainbowf1_search();

            if (tap.cbmid == LID_RAINBOWARTS    && ldrswt[norainbowf2].state == FALSE && !dbase_is_full && !aborted)
                rainbowf2_search();

            if (tap.cbmid == LID_BURNERVAR      && ldrswt[noburnervar].state == FALSE && !dbase_is_full && !aborted)
                burnervar_search();

            if (tap.cbmid == LID_OCNEW4     && ldrswt[nooceannew2   ].state == FALSE && !dbase_is_full && !aborted)
                oceannew4_search();

            if (tap.cbmid == LID_FREE_SLOW     && ldrswt[nofrslow    ].state == FALSE && !dbase_is_full && !aborted)
                freeslow_search();

            /* todo : TURRICAN
             * todo : SEUCK
             * todo : JETLOAD
             * todo : TENGEN
             */
        }

        /* Scan the lot.. (if shortcuts are disabled or no loader ID was found) */

        if ((noid == FALSE && tap.cbmid == 0) || (noid == TRUE)) {

            if (ldrswt[nogaladriel  ].state == FALSE && !dbase_is_full && !aborted)
                galadriel_search(); /* iAN: check galadriel first, then TurboTape, avoids false alarms */

            if (ldrswt[nonext       ].state == FALSE && !dbase_is_full && !aborted)
                turbotape_search(NEXT_HEAD);

            if (ldrswt[noloadnrun   ].state == FALSE && !dbase_is_full && !aborted)
                turbotape_search(LOADNRUN_HEAD);

            if (ldrswt[no7bit       ].state == FALSE && !dbase_is_full && !aborted)
                turbotape_search(NOTEBIT_HEAD);

            if (ldrswt[noturbo      ].state == FALSE && !dbase_is_full && !aborted)
                turbotape_search(TT_HEAD);

            if (ldrswt[noeasytape   ].state == FALSE && !dbase_is_full && !aborted)
                easytape_search();

            if (ldrswt[noar         ].state == FALSE && !dbase_is_full && !aborted)
                ar_search();

            if (ldrswt[nosmagic     ].state == FALSE && !dbase_is_full && !aborted)
                smagic_search(SMAGIC2);

            if (ldrswt[noyc         ].state == FALSE && !dbase_is_full && !aborted)
                smagic_search(YOURCOM);

            if (ldrswt[noff         ].state == FALSE && !dbase_is_full && !aborted)
                ff_search();

            if (ldrswt[nofree       ].state == FALSE && !dbase_is_full && !aborted)
                freeload_search();

            if (ldrswt[noode        ].state == FALSE && !dbase_is_full && !aborted)
                odeload_search();

            if (ldrswt[nocult       ].state == FALSE && !dbase_is_full && !aborted)
                cult_search();

            /* comes here to avoid ocean misdetections
             * snakeload is a 'safer' scanner than ocean.
             */

            if (ldrswt[nosnake50    ].state == FALSE && !dbase_is_full && !aborted) {
                snakeload50t1_search();
                snakeload50t2_search();
            }

            if (ldrswt[nosnake51    ].state == FALSE && !dbase_is_full && !aborted)
                snakeload51_search();

            if (ldrswt[nonova       ].state == FALSE && !dbase_is_full && !aborted) {
                nova_spc_search();
                nova_search();
            }

            if (ldrswt[nobleep      ].state == FALSE && !dbase_is_full && !aborted) {
                bleep_search();
                bleep_spc_search();
            }

            if (ldrswt[noocean      ].state == FALSE && !dbase_is_full && !aborted)
                ocean_search();

            if (ldrswt[nocyber      ].state == FALSE && !dbase_is_full && !aborted) {
                cyberload_f1_search();
                cyberload_f2_search();
                cyberload_f3_search();
                cyberload_f4_search();
            }

            if (ldrswt[nousgold     ].state == FALSE && !dbase_is_full && !aborted)
                usgold_search();

            if (ldrswt[noaces       ].state == FALSE && !dbase_is_full && !aborted)
                aces_search();

            if (ldrswt[nomicro      ].state == FALSE && !dbase_is_full && !aborted)
                micro_search();

            if (ldrswt[noraster     ].state == FALSE && !dbase_is_full && !aborted)
                raster_search();

            if (ldrswt[nochr        ].state == FALSE && !dbase_is_full && !aborted)
                chr_search();

            if (ldrswt[noburner     ].state == FALSE && !dbase_is_full && !aborted)
                burner_search();

            if (ldrswt[novisi       ].state == FALSE && !dbase_is_full && !aborted)
                visiload_search();

            if (ldrswt[nowild       ].state == FALSE && !dbase_is_full && !aborted)
                wild_search();

            if (ldrswt[nohit        ].state == FALSE && !dbase_is_full && !aborted)
                hitload_search();

            if (ldrswt[norackit     ].state == FALSE && !dbase_is_full && !aborted)
                rackit_search();

            if (ldrswt[nospav       ].state == FALSE && !dbase_is_full && !aborted)
                superpav_search();

            if (ldrswt[noanirog     ].state == FALSE && !dbase_is_full && !aborted)
                anirog_search();

            if (ldrswt[nosuper      ].state == FALSE && !dbase_is_full && !aborted)
                supertape_search();

            if (ldrswt[nofire       ].state == FALSE && !dbase_is_full && !aborted)
                firebird_search();

            if (ldrswt[nopav        ].state == FALSE && !dbase_is_full && !aborted)
                pav_search();

            if (ldrswt[noik         ].state == FALSE && !dbase_is_full && !aborted)
                ik_search();

            if (ldrswt[noturr       ].state == FALSE && !dbase_is_full && !aborted)
                turrican_search();

            if (ldrswt[noseuck      ].state == FALSE && !dbase_is_full && !aborted)
                seuck1_search();

            if (ldrswt[nojet        ].state == FALSE && !dbase_is_full && !aborted)
                jetload_search();

            if (ldrswt[noflash      ].state == FALSE && !dbase_is_full && !aborted)
                flashload_search();

            if (ldrswt[novirgin     ].state == FALSE && !dbase_is_full && !aborted)
                virgin_search();

            if (ldrswt[nohitec      ].state == FALSE && !dbase_is_full && !aborted)
                hitec_search();

            if (ldrswt[notdif2      ].state == FALSE && !dbase_is_full && !aborted) /* check f2 first (luigi) */
                tdif2_search();

            if (ldrswt[notdif1      ].state == FALSE && !dbase_is_full && !aborted)
                tdi_search();

            if (ldrswt[nooceannew1t1].state == FALSE && !dbase_is_full && !aborted)
                oceannew1t1_search();

            if (ldrswt[nooceannew1t2].state == FALSE && !dbase_is_full && !aborted)
                oceannew1t2_search();

            if (ldrswt[nooceannew2  ].state == FALSE && !dbase_is_full && !aborted)
                oceannew2_search();

            if (ldrswt[noatlantis   ].state == FALSE && !dbase_is_full && !aborted)
                atlantis_search();

            if (ldrswt[nopalacef1   ].state == FALSE && !dbase_is_full && !aborted)
                palacef1_search();

            if (ldrswt[nopalacef2   ].state == FALSE && !dbase_is_full && !aborted)
                palacef2_search();

            if (ldrswt[noenigma     ].state == FALSE && !dbase_is_full && !aborted)
                enigma_search();

            if (ldrswt[noaudiogenic ].state == FALSE && !dbase_is_full && !aborted)
                audiogenic_search();

            if (ldrswt[noaliensy    ].state == FALSE && !dbase_is_full && !aborted)
                aliensyndrome_search();

            if (ldrswt[noaccolade   ].state == FALSE && !dbase_is_full && !aborted)
                accolade_search();

            if (ldrswt[noalterwg    ].state == FALSE && !dbase_is_full && !aborted)
                alternativewg_search();

            if (ldrswt[norainbowf1  ].state == FALSE && !dbase_is_full && !aborted)
                rainbowf1_search();

            if (ldrswt[norainbowf2  ].state == FALSE && !dbase_is_full && !aborted)
                rainbowf2_search();

            if (ldrswt[notrilogic   ].state == FALSE && !dbase_is_full && !aborted)
                trilogic_search();

            if (ldrswt[noburnervar  ].state == FALSE && !dbase_is_full && !aborted)
                burnervar_search();

            if (ldrswt[nooceannew4  ].state == FALSE && !dbase_is_full && !aborted)
                oceannew4_search();

            if (ldrswt[noashdave    ].state == FALSE && !dbase_is_full && !aborted)
                ashdave_search();

            if (ldrswt[nofrslow    ].state == FALSE && !dbase_is_full && !aborted)
                freeslow_search();

        }

        sort_blocks();  /* sort the blocks into order of appearance */
        scan_gaps();    /* add any gaps to the block list */
        sort_blocks();  /* sort the blocks into order of appearance */

        tap.changed=0;  /* important to clear this. */

        if (quiet)
            msgout("  Done.");
    } else
        msgout("  Done.");
}

/*
 * Write a description of a GAP file to global buffer 'info' for inclusion in
 * the report.
 */

static void gap_describe(int row)
{
    strcpy(lin, "");

    if (blk[row]->xi > 1)
        sprintf(lin, "\n - Length = %d pulses", blk[row]->xi);
    else
        sprintf(lin, "\n - Length = %d pulse", blk[row]->xi);

    strcpy(info, lin);
}

/*
 * Pass this function a valid row number (i) from the file database (blk) and
 * it calls the describe function for that file format which will decode
 * any data in the block and fill in all missing information for that file.
 *
 * Note: Any "additional" (unstored in the database) text info will be available
 * in the global buffer 'info'. (this could be improved).
 */

static void describe_file(int row)
{
    int t;
    t = blk[row]->lt;

    switch(t)
    {
        case GAP:             gap_describe(row);            break;
        case PAUSE:           pause_describe(row);          break;
        case CBM_HEAD:        cbm_describe(row);            break;
        case CBM_DATA:        cbm_describe(row);            break;
        case USGOLD:          usgold_describe(row);         break;
        case TT_HEAD:         turbotape_describe(row);      break;
        case TT_DATA:         turbotape_describe(row);      break;
        case FREE:            freeload_describe(row);       break;
        case ODELOAD:         odeload_describe(row);        break;
        case CULT:            cult_describe(row);           break;
        case CHR_T1:          chr_describe(row);            break;
        case CHR_T2:          chr_describe(row);            break;
        case CHR_T3:          chr_describe(row);            break;
        case NOVA:            nova_describe(row);           break;
        case NOVA_SPC:        nova_spc_describe(row);       break;
        case WILD:            wild_describe(row);           break;
        case WILD_STOP:       wild_describe(row);           break;
        case ACES:            aces_describe(row);           break;
        case OCEAN_F1:        ocean_describe(row);          break;
        case OCEAN_F2:        ocean_describe(row);          break;
        case OCEAN_F3:        ocean_describe(row);          break;
        case RASTER:          raster_describe(row);         break;
        case VISI_T1:         visiload_describe(row);       break;
        case VISI_T2:         visiload_describe(row);       break;
        case VISI_T3:         visiload_describe(row);       break;
        case VISI_T4:         visiload_describe(row);       break;
        case CYBER_F1:        cyberload_f1_describe(row);   break;
        case CYBER_F2:        cyberload_f2_describe(row);   break;
        case CYBER_F3:        cyberload_f3_describe(row);   break;
        case CYBER_F4_1:      cyberload_f4_describe(row);   break;
        case CYBER_F4_2:      cyberload_f4_describe(row);   break;
        case CYBER_F4_3:      cyberload_f4_describe(row);   break;
        case BLEEP:           bleep_describe(row);          break;
        case BLEEP_TRIG:      bleep_describe(row);          break;
        case BLEEP_SPC:       bleep_spc_describe(row);      break;
        case HITLOAD:         hitload_describe(row);        break;
        case MICROLOAD:       micro_describe(row);          break;
        case BURNER:          burner_describe(row);         break;
        case RACKIT:          rackit_describe(row);         break;
        case SPAV1_HD:        superpav_describe(row);       break;
        case SPAV2_HD:        superpav_describe(row);       break;
        case SPAV1:           superpav_describe(row);       break;
        case SPAV2:           superpav_describe(row);       break;
        case VIRGIN:          virgin_describe(row);         break;
        case HITEC:           hitec_describe(row);          break;
        case ANIROG:          anirog_describe(row);         break;
        case SUPERTAPE_HEAD:  supertape_describe(row);      break;
        case SUPERTAPE_DATA:  supertape_describe(row);      break;
        case PAV:             pav_describe(row);            break;
        case IK:              ik_describe(row);             break;
        case FBIRD1:          firebird_describe(row);       break;
        case FBIRD2:          firebird_describe(row);       break;
        case TURR_HEAD:       turrican_describe(row);       break;
        case TURR_DATA:       turrican_describe(row);       break;
        case SEUCK_L2:        seuck1_describe(row);         break;
        case SEUCK_HEAD:      seuck1_describe(row);         break;
        case SEUCK_DATA:      seuck1_describe(row);         break;
        case SEUCK_TRIG:      seuck1_describe(row);         break;
        case SEUCK_GAME:      seuck1_describe(row);         break;
        case JET:             jetload_describe(row);        break;
        case FLASH:           flashload_describe(row);      break;
        case TDI_F1:          tdi_describe(row);            break;
        case OCNEW1T1:        oceannew1t1_describe(row);    break;
        case OCNEW1T2:        oceannew1t2_describe(row);    break;
        case ATLAN:           atlantis_describe(row);       break;
        case SNAKE51:         snakeload51_describe(row);    break;
        case SNAKE50T1:       snakeload50t1_describe(row);  break;
        case SNAKE50T2:       snakeload50t2_describe(row);  break;
        case PAL_F1:          palacef1_describe(row);       break;
        case PAL_F2:          palacef2_describe(row);       break;
        case OCNEW2:          oceannew2_describe(row);      break;
        case ENIGMA:          enigma_describe(row);         break;
        case AUDIOGENIC:      audiogenic_describe(row);     break;
        case ALIENSY:         aliensyndrome_describe(row);  break;
        case ACCOLADE:        accolade_describe(row);       break;
        case ALTERWG:         alternativewg_describe(row);  break;
        case RAINBOWARTSF1:   rainbowf1_describe(row);      break;
        case RAINBOWARTSF2:   rainbowf2_describe(row);      break;
        case TRILOGIC:        trilogic_describe(row);       break;
        case BURNERVAR:       burnervar_describe(row);      break;
        case OCNEW4:          oceannew4_describe(row);      break;
        case TDI_F2:          tdif2_describe(row);          break;
        case GALADRIEL:       galadriel_describe(row);      break;
        case GALADRIEL_XOR:   galadriel_describe(row);      break;
        case GALADRIEL_BOB85: galadriel_describe(row);      break;
        case GALADRIEL_POKE:  galadriel_describe(row);      break;
        case GALADRIEL_POKE1: galadriel_describe(row);      break;
        case GALADRIEL_REV:   galadriel_describe(row);      break;
        case EASYTAPE1:       easytape_describe(row);       break;
        case EASYTAPE2:       easytape_describe(row);       break;
        case ACTIONREPLAY:    ar_describe(row);             break;
        case ATOMICPOWER:     ar_describe(row);             break;
        case SMAGIC2:         smagic_describe(row);         break;
        case NEXT_HEAD:       turbotape_describe(row);      break;
        case NEXT_DATA:       turbotape_describe(row);      break;
        case LOADNRUN_HEAD:   turbotape_describe(row);      break;
        case LOADNRUN_DATA:   turbotape_describe(row);      break;
        case NOTEBIT_HEAD:    turbotape_describe(row);      break;
        case NOTEBIT_DATA:    turbotape_describe(row);      break;
        case FREEZEFRAME:     ff_describe(row);             break;
        case ASHDAVE:         ashdave_describe(row);        break;
        case FREE_SLOW:       freeslow_describe(row);       break;
        case YOURCOM  :       smagic_describe(row);         break;
    }
}

/*
 * Describes each file in the database, this calls the loadername_describe()
 * function for the files type which fills in all missing information and
 * decodes each file.
 */

static void describe_blocks(void)
{
    int i, t, re;

    tap.total_read_errors = 0;

    for (i = 0; blk[i]->lt != 0; i++) {
        t = blk[i]->lt;

        describe_file(i);

        /* get generic info that all data blocks have... */

        if (t > PAUSE) {

            /* make crc32 if the block has been data extracted. */

            if (blk[i]->dd != NULL)
                blk[i]->crc = compute_crc32(blk[i]->dd, blk[i]->cx);

            re = blk[i]->rd_err;
            tap.total_read_errors += re;
        }
    }
}

/*
 * Save buffer tap.tmem[] to a named file.
 * Return 1 on success, 0 on error.
 */

static int save_tap(char *name)
{
    FILE *fp;

    fp = fopen(name, "w+b");
    if (fp == NULL || tap.tmem == NULL)
        return 0;

    fwrite(tap.tmem, tap.len, 1, fp);
    fclose(fp);
    return 1;
}

/*
 * Look at the TAP header and verify signature as C64 TAP.
 * Return 0 if ok else 1.
 */

static int check_signature(void)
{
    int i;

    /* copy 1st 12 chars, strncpy fucks it up somehow. */

    for (i = 0; i < 12; i++)
        lin[i] = tap.tmem[i];

    lin[i] = 0;
    /* iAN */
    if(c64)
    {
        if (strcmp(lin, "C64-TAPE-RAW") == 0)
            return 0;
        else
            return 1;
    }

    if(c20)
    {
        /* never found, just in case add also this */
        if (strcmp(lin, "V20-TAPE-RAW") == 0)
            return 0;
        /* all vic20 taps i found have normal c64 header */
        if (strcmp(lin, "C64-TAPE-RAW") == 0)
            return 0;
        else
            return 1;
    }

    if(c16)
    {
        if (strcmp(lin, "C16-TAPE-RAW") == 0)
            return 0;
        else
            return 1;
    }
    /* if anything else fails */
    return 1;
}

/*
 * Look at the TAP header and verify version, currently 0 and 1 are valid versions.
 * Sets 'version' variable and returns 0 on success, else returns 1.
 */

static int check_version(void)
{
    int b;

    b = tap.tmem[12];
    /* iAN */
    if(c64||c20)
    {
        if (b == 0 || b == 1)
        {
            tap.version = b;
            return 0;
        }
        else
            return 1;
    }

    if(c16)
    {
        if (b == 1 || b == 2)
        {
            tap.version = 1;
            ft [CBM_HEAD].sp = 0x35/b;
            ft [CBM_HEAD].mp = 0x6A/b;
            ft [CBM_HEAD].lp = 0xD4/b;
            /* weirdness in tap v2:
               every pulse is halved BUT repeated 2 times
               35    6a    d4     tap v1
               19 19 35 35 67 67  tap v2
            */
            ft [CBM_DATA].sp = ft [CBM_HEAD].sp;
            ft [CBM_DATA].mp = ft [CBM_HEAD].mp;
            ft [CBM_DATA].lp = ft [CBM_HEAD].lp;
            return 0;
        }
        else
            return 1;
    }
    /* if anything else fails */
    return 1;

}
/*
c16 tap 1
00000000:  43 31 36 2D-54 41 50 45-2D 52 41 57-01 02 00 00
              ^^^^^                            ^^
00004006:  35 35 35 35-35 35 35 35-35 35 35 35-35 35 35 35
00004016:  D2 68 68 35-35 68 35 68-68 35 35 68-35 68 35 68
00004026:  68 35 35 68-D2 68 35 68-35 68 35 68-68 35 35 68
00004036:  35 68 35 68-68 35 68 35-D2 68 68 35-68 35 68 35
00004046:  35 68 35 68-35 68 35 68-68 35 68 35-D2 68 35 68
00004056:  68 35 68 35-35 68 35 68-35 68 35 68-68 35 35 68
00004066:  D2 68 68 35-35 68 68 35-35 68 35 68-35 68 35 68
00004076:  68 35 35 68-D2 68 35 68-35 68 68 35-35 68 35 68
00004086:  35 68 35 68-68 35 68 35-D2 68 68 35-68 35 35 68
00004096:  35 68 35 68-35 68 35 68-68 35 35 68-D2 68 35 68
000040A6:  68 35 35 68-35 68 35 68-35 68 35 68-68 35 68 35

c16 tap 2
00000000:  43 31 36 2D-54 41 50 45-2D 52 41 57-02 02 00 00
              ^^^^^                            ^^
00008005:  19 19 19 19-19 19 19 19-19 19 19 19-19 19 19 19
00008015:  69 69 35 35-35 35 19 19-19 19 35 35-19 19 35 35
00008025:  35 35 19 19-19 19 35 35-19 19 35 35-19 19 35 35
00008035:  35 35 19 19-19 19 35 35-69 69 35 35-19 19 35 35
00008045:  19 19 35 35-19 19 35 35-35 35 19 19-19 19 35 35
00008055:  19 19 35 35-19 19 35 35-35 35 19 19-35 35 19 19
00008065:  69 69 35 35-35 35 19 19-35 35 19 19-35 35 19 19
00008075:  19 19 35 35-19 19 35 35-19 19 35 35-19 19 35 35
00008085:  35 35 19 19-35 35 19 19-69 69 35 35-19 19 35 35
00008095:  35 35 19 19-35 35 19 19-19 19 35 35-19 19 35 35
000080A5:  19 19 35 35-19 19 35 35-35 35 19 19-19 19 35 35
000080B5:  69 69 35 35-35 35 19 19-19 19 35 35-35 35 19 19
000080C5:  19 19 35 35-19 19 35 35-19 19 35 35-19 19 35 35
000080D5:  35 35 19 19-19 19 35 35-69 69 35 35-19 19 35 35
*/

/*
 * Verifies the TAP header 'size' field.
 * Returns 0 if ok, else 1.
 */

static int check_size(void)
{
    int sz;

    sz = tap.tmem[16] + (tap.tmem[17] << 8) + (tap.tmem[18] << 16) + (tap.tmem[19] << 24);
    if (sz == tap.len - 20)
        return 0;
    else
        return 1;
}

/*
 * Return the duration in seconds between p1 and p2.
 * p1 and p2 should be valid offsets within the scope of the TAP file.
 */

static float get_duration(int p1, int p2)
{
    int i;
    int zsum;
    double tot = 0;
    double p = (double)20000 / cps;
    float apr;

    for (i = p1; i < p2; i++) {

        /* handle normal pulses (non-zeroes) */

        if (tap.tmem[i] != 0)
            tot += ((double)(tap.tmem[i] * 8) / cps);

        /* handle v0 zeroes.. */

        if (tap.tmem[i] == 0 && tap.version == 0)
            tot += p;

        /* handle v1 zeroes.. */

        if (tap.tmem[i] == 0 && tap.version == 1) {
            zsum = tap.tmem[i + 1] + (tap.tmem[i + 2] << 8) + (tap.tmem[i + 3] << 16);
            tot += (double)zsum / cps;
            i += 3;
        }
    }

    apr = (float)tot;   /* approximate and return number of seconds. */
    return apr;
}

/*
 * Return the number of unique pulse widths in the TAP.
 * Note: Also fills tap.pst[256] array with distribution stats.
 */

static int get_pulse_stats(void)
{
    int i, tot, b;

    for(i = 0; i < 256; i++)    /* clear pulse table...  */
        tap.pst[i] = 0;

    /* create pulse table... */

    for (i = 20; i < tap.len; i++) {
        b = tap.tmem[i];
        if (b == 0 && tap.version == 1)
            i += 3;
        else
            tap.pst[b]++;
    }

    /* add up pulse types... */

    tot = 0;

    /* Note the start at 1 (pauses dont count) */

    for (i = 1; i < 256; i++) {
        if (tap.pst[i] != 0)
            tot++;
    }

    return tot;
}

/*
 * Count all file types found in the TAP and their quantities.
 * Also records the number of data files, checksummed data files and gaps in the TAP.
 */

static void get_file_stats(void)
{
    int i;

    for (i = 0; i < 256; i++)   /* init table */
        tap.fst[i] = 0;

    /* count all contained filetype occurences... */

    for (i = 0; blk[i]->lt != 0; i++)
        tap.fst[blk[i]->lt]++;

    tap.total_data_files = 0;
    tap.total_checksums = 0;
    tap.total_gaps = 0;

    /* for each file format in ft[]...  */

    for (i = 0; ft[i].sp != 666; i++) {
        if (tap.fst[i] != 0) {
            if (ft[i].has_cs == CSYES)
                tap.total_checksums += tap.fst[i];  /* count all available checksums. */
        }

        if (i > PAUSE)
            tap.total_data_files += tap.fst[i];     /* count data files */

        if (i == GAP)
            tap.total_gaps += tap.fst[i];           /* count gaps */
    }
}

/*
 * Print the human readble TAP report to a buffer.
 * Note: this is done so I can send the info to both the screen and the report
 * without repeating the code.
 * Note: Call 'analyze()' before calling this!.
 */

static void print_results(char *buf)
{
    char tstr[2][8] = {"PASS", "FAIL"};
    char tstr2[2][8] = {"OK", "FAIL"};
    int min;
    float sec;

    sprintf(buf, "\nGENERAL INFO AND TEST RESULTS\n");

    sprintf(lin, "\nTAP Name    : %s", tap.path);
    strcat(buf, lin);

    sprintf(lin, "\nTAP Size    : %d bytes (%d kB)", tap.len, tap.len >> 10);
    strcat(buf, lin);
    sprintf(lin, "\nTAP Version : %d", tap.version);
    strcat(buf, lin);
    sprintf(lin, "\nRecognized  : %d%s", tap.detected_percent, "%%");
    strcat(buf, lin);
    sprintf(lin, "\nData Files  : %d", tap.total_data_files);
    strcat(buf, lin);
    sprintf(lin, "\nPauses      : %d", count_pauses());
    strcat(buf, lin);
    sprintf(lin, "\nGaps        : %d", tap.total_gaps);
    strcat(buf, lin);
    sprintf(lin, "\nMagic CRC32 : %08X", tap.crc);
    strcat(buf, lin);
    min = (int)(tap.taptime / 60);
    sec = tap.taptime - min * 60;
    sprintf(lin, "\nTAP Time    : %d:%.2f", min, sec);
    strcat(buf, lin);

    if (tap.bootable) {
        if (tap.bootable == 1)
            sprintf(lin, "\nBootable    : YES (1 part, name: %s)", pet2text(tmp, tap.cbmname));
        else
            sprintf(lin, "\nBootable    : YES (%d parts, 1st name: %s)", tap.bootable, pet2text(tmp, tap.cbmname));
        strcat(buf, lin);
    } else {
        sprintf(lin, "\nBootable    : NO");
        strcat(buf, lin);
    }

    sprintf(lin, "\nLoader ID   : %s", knam[tap.cbmid]);
    strcat(buf, lin);

    /* TEST RESULTS... */

    sprintf(lin, "\n");
    strcat(buf, lin);

    sprintf(lin, "\nOverall Result    : %s",tstr[!!(tap.tst_hd||tap.tst_rc||tap.tst_cs||tap.tst_rd||tap.tst_op)]);
    strcat(buf, lin);

    sprintf(lin, "\n");
    strcat(buf, lin);
    sprintf(lin, "\nHeader test       : %s [Sig: %s] [Ver: %s] [Siz: %s]", tstr[tap.tst_hd], tstr2[tap.fsigcheck], tstr2[tap.fvercheck], tstr2[tap.fsizcheck]);
    strcat(buf, lin);
    sprintf(lin, "\nRecognition test  : %s [%d of %d bytes accounted for] [%d%s]", tstr[tap.tst_rc], tap.detected, tap.len - 20, tap.detected_percent,"%%");
    strcat(buf, lin);
    sprintf(lin, "\nChecksum test     : %s [%d of %d checksummed files OK]", tstr[tap.tst_cs], tap.total_checksums_good, tap.total_checksums);
    strcat(buf, lin);
    sprintf(lin, "\nRead test         : %s [%d Errors]", tstr[tap.tst_rd], tap.total_read_errors);
    strcat(buf, lin);
    sprintf(lin, "\nOptimization test : %s [%d of %d files OK]", tstr[tap.tst_op], tap.optimized_files, tap.total_data_files);
    strcat(buf, lin);
    sprintf(lin, "\n");
    strcat(buf, lin);
}

/*
 * Note: This one prints out a fully interprets all file info and includes extra
 * text infos generated by xxxxx_describe functions.
 */

static void print_database(char *buf)
{
    int i;

    sprintf(buf, "\n\nFILE DATABASE\n");

    for (i = 0; blk[i]->lt != 0; i++) {
        sprintf(lin, "\n---------------------------------");
        strcat(buf, lin);
        sprintf(lin, "\nFile Type: %s", ft[blk[i]->lt].name);
        strcat(buf, lin);
        sprintf(lin, "\nLocation: $%04X -> $%04X -> $%04X -> $%04X", blk[i]->p1, blk[i]->p2, blk[i]->p3, blk[i]->p4);
        strcat(buf, lin);

        if (blk[i]->lt > PAUSE) {       /* info for data files only... */
            sprintf(lin, "\nLA: $%04X  EA: $%04X  SZ: %d", blk[i]->cs, blk[i]->ce, blk[i]->cx);
            strcat(buf, lin);

            /* iAN: print also start address for those having this extra info */
            if(   blk[i]->lt == GALADRIEL_POKE
                ||blk[i]->lt == GALADRIEL_POKE1
                ||blk[i]->lt == GALADRIEL_BOB85)
            {
                //if(blk[i]->xi>=0x400)
                {
                    sprintf(lin, "  SA: $%04X ", blk[i]->xi);
                    strcat(buf, lin);
                }
            }
            if(  blk[i]->lt == GALADRIEL
               ||blk[i]->lt == GALADRIEL_XOR)
            {
                //if(blk[i]->cs_exp>=0x400)
                {
                    sprintf(lin, "  SA: $%04X ", blk[i]->cs_exp);
                    strcat(buf, lin);
                }
            }

            if (blk[i]->fn != NULL) {   /* filename, if applicable */
                sprintf(lin, "\nFile Name: %s", blk[i]->fn);
                strcat(buf, lin);
            }

            sprintf(lin, "\nPilot/Trailer Size: %d/%d", blk[i]->pilot_len, blk[i]->trail_len);
            strcat(buf, lin);

            if (ft[blk[i]->lt].has_cs == TRUE) {    /* checkbytes, if applicable */
                sprintf(lin, "\nCheckbyte Actual/Expected: $%02X/$%02X %s", blk[i]->cs_act, blk[i]->cs_exp,(blk[i]->cs_act== blk[i]->cs_exp?"PASS":"FAIL"));
                strcat(buf, lin);
            }

            sprintf(lin, "\nRead Errors: %d", blk[i]->rd_err);
            strcat(buf, lin);
            sprintf(lin, "\nUnoptimized Pulses: %d", count_unopt_pulses(i));
            strcat(buf, lin);
            sprintf(lin, "\nCRC32: %08X", blk[i]->crc);
            strcat(buf, lin);
        }

        strcpy(info, "");       /* clear 'info' ready to receive additional text */
        describe_file(i);
        strcat(buf, info);  /* add additional text */
        strcat(buf, "\n");
    }
}

/*
 * Print pulse stats to buffer 'buf'.
 * Note: Call 'analyze()' before calling this!.
 */

static void print_pulse_stats(char *buf)
{
    int i;

    sprintf(buf, "\nPULSE FREQUENCY TABLE\n");

    for (i = 1; i < 256; i++) {
        if (tap.pst[i] != 0) {
            sprintf(lin, "\n0x%02X (%d)", i, tap.pst[i]);
            strcat(buf, lin);
        }
    }
}

/*
 * Print file stats to buffer 'buf'.
 * Note: Call 'analyze()' before calling this!.
 */

static void print_file_stats(char *buf)
{
    int i;

    sprintf(buf, "\nFILE FREQUENCY TABLE\n");

    for (i = 0; ft[i].sp != 666; i++) { /* for each file format in ft[]...  */
        if (tap.fst[i] != 0) {      /* list all found files and their frequency...  */
            sprintf(lin, "\n%s (%d)", ft[i].name, tap.fst[i]);
            strcat(buf, lin);
        }
    }
}


/**
 *  TAPClean entry point
 */

int main(int argc, char *argv[])
{
    int opnum;
    time_t t1, t2;

    char *opname;       /*!< a pointer to one of the following opnames */
    char opnames[][32] = {
        "No operation",
        "Testing",
        "Optimizing",
        "Converting to v0",
        "Converting to v1",
        "Fixing header size",
        "Optimizing pauses",
        "Converting to au file",
        "Converting to wav file",
        "Batch scanning",
        "Creating info file"
    };

    /* Delete report and info files */
    deleteworkfiles();

    /* Get exe path from argv[0] */
    if (!get_exedir(argv[0]))
        return -1;

    /* Allocate database for files (not always needed, but still here) */
    if (!create_database())
        return -1;

    /* TBA */
    copy_loader_table();

    /* TBA */
    build_crc_table();

    printf("\n");
    //printf("-------------------------------------------------------------------------------\n");
    printf(VERSION_STR" [Build: "__DATE__" by "BUILDER"]\n");
    printf("Based on Final TAP 2.76 Console - (C) 2001-2006 Subchrist Software\n");
    printf("Based on TapClean 0.20 & parts of 0.21/0.22 (bokvamme, tce, fabbo)\n");
    //printf("-------------------------------------------------------------------------------\n");

    /* Note: options should be processed before actions! */

    if (argc == 1) {
        display_usage();
        //printf("\n\n");
        cleanup_main();
        return 0;
    }

    process_options(argc, argv);
    handle_cps();

    /* PROCESS ACTIONS... */

    /**
     *  Just test a tap if no option is present, just a filename.
     *
     *  This allows for drag and drop in (Microsoft) explorer.
     *  First make sure the argument is not the -b option without
     *  arguments, or the -info option.
     */

    if (argc == 2 && strcmp(argv[1], "-b") && strcmp(argv[1], "-info")) {
        if (load_tap(argv[1])) {
            printf("\n\nLoaded: %s", tap.name);
            printf("\nTesting...\n");
            time(&t1);
            if (analyze()) {
                report();
                printf("\n\nSaved: %s", tcreportname);
                time(&t2);
                time2str(t2 - t1, lin);
                printf("\nOperation completed in %s.", lin);
            }
        }
    } else {
        int i;

        for (i = 0; i < argc; i++) {
            opnum = 0;
            if (strcmp(argv[i], "-t") == 0)
                opnum = 1;  /* test */
            if (strcmp(argv[i], "-o") == 0)
                opnum = 2;  /* optimize */
            if (strcmp(argv[i], "-ct0") == 0)
                opnum = 3;  /* convert to v0 */
            if (strcmp(argv[i], "-ct1") == 0)
                opnum = 4;  /* convert to v1 */
            if (strcmp(argv[i], "-rs") == 0)
                opnum = 5;  /* fix header size */
            if (strcmp(argv[i], "-po") == 0)
                opnum = 6;  /* pause optimize */

            if (strcmp(argv[i], "-au") == 0)
                opnum = 7;  /* convert to au */
            if (strcmp(argv[i], "-wav") == 0)
                opnum = 8;  /* convert to wav */
            if (strcmp(argv[i], "-b") == 0)
                opnum = 9;  /* batch scan */
            if (strcmp(argv[i], "-info") == 0)
                opnum = 10; /* create info file */

            opname = opnames[opnum];

            /* This handles testing + any op that takes a tap, affects it and saves it... */

            if (opnum > 0 && opnum < 7) {
                if (argv[i + 1] != NULL) {
                    if (load_tap(argv[i + 1])) {
                        time(&t1);
                        printf("\n\nLoaded: %s", tap.name);
                        printf("\n%s...\n", opname);

                        if (analyze()) {
                            switch(opnum) {
                                case 2: clean();
                                    break;
                                case 3: convert_to_v0();
                                    break;
                                case 4: convert_to_v1();
                                    break;
                                case 5: fix_header_size();
                                    analyze();
                                    break;
                                case 6: convert_to_v0();
                                    clip_ends();
                                    unify_pauses();
                                    convert_to_v1();
                                    add_trailpause();
                                    break;
                            }

                            report();
                            printf("\nSaved: %s", tcreportname);
                            if (opnum > 1) {
                                /*
                                strcpy(cleanedtapname, CLEANED_PREFIX);
                                strcat(cleanedtapname, tap.name);
                                */
                                char *p;
                                strcpy(cleanedtapname, tap.name);
                                p=strrchr(cleanedtapname,'.');if(p)*(p+1)=0;
                                if(!!(tap.tst_hd||tap.tst_rc||tap.tst_cs||tap.tst_rd||tap.tst_op))
                                    strcat(cleanedtapname, "dirty");
                                else
                                    strcat(cleanedtapname, "clean");
                                strcat(cleanedtapname, ".tap");
                                save_tap(cleanedtapname);
                                printf("\n\nSaved: %s", cleanedtapname);
                            }
                            time(&t2);
                            time2str(t2 - t1, lin);
                            printf("\nOperation completed in %s.", lin);
                        }
                    }
                } else
                    printf("\n\nMissing file name.");
            }

            if (opnum == 7) {   /* flag = convert to au */
                if (argv[i + 1] != NULL) {
                    if (load_tap(argv[i + 1])) {
                        if (analyze()) {
                            printf("\n\nLoaded: %s", tap.name);
                            printf("\n%s...\n", opname);
                            au_write(tap.tmem, tap.len, auoutname, sine);
                            printf("\nSaved: %s", auoutname);
                            msgout("\n");
                        }
                    }
                } else
                    printf("\n\nMissing file name.");
            }

            if (opnum == 8) {       /* flag = convert to wav */
                if (argv[i + 1] != NULL) {
                    if (load_tap(argv[i + 1])) {
                        if (analyze()) {
                            printf("\n\nLoaded: %s", tap.name);
                            printf("\n%s...\n", opname);
                            wav_write(tap.tmem, tap.len, wavoutname, sine);
                            printf("\nSaved: %s", wavoutname);
                            msgout("\n");
                        }
                    }
                } else
                    printf("\n\nMissing file name.");
            }

            if (opnum == 9) {       /* flag = batch scan... */
                batchmode = TRUE;
                quiet = TRUE;

                if (argv[i + 1] != NULL) {
                    printf("\n\nBatch Scanning: %s\n", argv[i + 1]);
                    batchscan(argv[i + 1], incsubdirs, 1);
                } else {
                    printf("\n\nMissing directory name, using current.");
                    printf("\n\nBatch Scanning: %s\n", exedir);
                    batchscan(exedir, incsubdirs, 1);
                }

                batchmode = FALSE;
                quiet = FALSE;
            }

            /* flag = generate exe info file */

            if (opnum == 10) {
                FILE *fp;

                fp = fopen(tcinfoname, "w+t");
                if (fp != NULL) {
                    printf("\n%s...\n", opname);
                    fprintf(fp, "%s", VERSION_STR);
                    fclose(fp);
                }
            }
        }
    }

    printf("\n\n");
    cleanup_main();

    return 0;
}

/*
 * Read 1 pulse from the tap file offset at 'pos', decide whether it is a Bit0 or Bit1
 * according to the values in the parameters. (+/- global tolerance value 'tol')
 * lp = ideal long pulse width.
 * sp = ideal short pulse width.
 * tp = threshold pulse width (can be NA if unknown)
 *
 * Return (bit value) 0 or 1 on success, else -1 on failure.
 *
 * Note: Most formats can use this (and readttbyte()) for reading data, but some
 * (ie. cbmtape, pavloda, visiload,supertape etc) have custom readers held in their
 * own source files.
 */

int readttbit(int pos, int lp, int sp, int tp)
{
    int valid, v=0, b;

    if (pos < 20 || pos > tap.len - 1)  /* return error if out of bounds.. */
        return -1;

    if (is_pause_param(pos))        /* return error if offset is on a pause.. */
        return -1;

    valid = 0;
    b = tap.tmem[pos];

    if (tp != NA) {             /* exact threshold pulse IS available... */
        if (b < tp && b > sp - tol) {   /* its a SHORT (Bit0) pulse... */
            v = 0;
            valid += 1;
        }

        if (b > tp && b < lp + tol) {   /* its a LONG (Bit1) pulse... */
            v = 1;
            valid += 2;
        }

        if (b == tp)            /* its ON the threshold!... */
        {   /* iAN */
            if (tp_flatten==0)
            {
                valid += 4;
            }
            else if(tp_flatten<0)
            {
                v = 0;
                valid += 1;
            }
            else /*if(tp_flatten>0)*/
            {
                v = 1;
                valid += 2;
            }
        }
    } else {                /* threshold unknown? ...use midpoint method... */
        if (b > (sp - tol) && b < (sp + tol)) { /* its a SHORT (Bit0) pulse...*/
            valid += 1;
            v = 0;
        }

        if (b > (lp - tol) && b < (lp + tol)) { /* its a LONG (Bit1) pulse... */
            valid += 2;
            v = 1;
        }

        if (valid == 3) {       /* pulse qualified as 0 AND 1!, use closest match... */
            if ((abs(lp - b)) > (abs(sp - b)))
                v = 0;
            else
                v = 1;
        }
    }

    if (valid == 0) {           /* Error, pulse didnt qualify as either Bit0 or Bit1... */
        add_read_error(pos);
        v = -1;
    }

    if (valid == 4) {           /* Error, pulse is ON the threshold... */
        add_read_error(pos);
        v = -1;
    }

    return v;
}

/*
 * Generic "READ_BYTE" function, (can be used by most turbotape formats)
 * Reads and decodes 8 pulses from 'pos' in the TAP file.
 * parameters...
 * lp = ideal long pulse width.
 * sp = ideal short pulse width.
 * tp = threshold pulse width (can be NA if unknown)
 * return 0 or 1 on success else -1.
 * endi = endianess (use constants LSbF or MSbF).
 * Returns byte value on success, or -1 on failure.
 *
 * Note: Most formats can use this (and readttbit) for reading data, but some
 * (ie. cbmtape, pavloda, visiload,supertape etc) have custom readers held in their
 * own source files.
 */

int readttbyte(int pos, int lp, int sp, int tp, int endi)
{
    int i, v, b;
    unsigned char byte[10];

    /* check next 8 pulses are not inside a pause and *are* inside the TAP... */

    for(i = 0; i < 8; i++) {
        b = readttbit(pos + i, lp, sp, tp);
        if (b == -1)
            return -1;
        else
            byte[i] = b;
    }

    /* if we get this far, we have 8 valid bits... decode the byte... */

    if (endi == MSbF) {
        v = 0;
        for (i = 0; i < 8; i++) {
            if (byte[i] == 1)
                v += (128 >> i);
        }
    } else {
        v = 0;
        for (i = 0; i < 8; i++) {
            if (byte[i] == 1)
            v += (1 << i);
        }
    }

    return v;
}

/*---------------------------------------------------------------------------
 * Search for pilot/sync sequence at offset 'pos' in tap file...
 * 'fmt' should be the numeric ID (or constant) of a format described in ft[].
 *
 * Returns 0 if no pilot found.
 * Returns end position if pilot found (and a legal quantity of them).
 * Returns end position (negatived) if pilot found but too few/many.
 *
 * Note: End position = file offset of 1st NON pilot value, ie. a sync byte.
 */

int find_pilot(int pos, int fmt)
{
    int z, sp, lp, tp, en, pv, sv, pmin, pmax;

    if (pos < 20)
        return 0;

    sp = ft[fmt].sp;
    lp = ft[fmt].lp;
    tp = ft[fmt].tp;
    en = ft[fmt].en;
    pv = ft[fmt].pv;
    sv = ft[fmt].sv;
    pmin = ft[fmt].pmin;
    pmax = ft[fmt].pmax;

    if (pmax == NA)
        pmax = 200000;      /* set some crazy limit if pmax is NA (NA=0) */

    if ((pv == 0 || pv == 1) && (sv == 0 || sv == 1)) { /* are the pilot/sync BIT values?... */
        if (readttbit(pos, lp, sp, tp) == pv) {     /* got pilot bit? */
            z = 0;
            while(readttbit(pos, lp, sp, tp) == pv && pos < tap.len) {  /* skip all pilot bits.. */
                z++;
                pos++;
            }

            if (z == 0)
                return 0;

            if (z < pmin || z > pmax)   /* too few/many pilots?, return position as negative. */
                return -pos;

            if (z >= pmin && z <= pmax) /* enough pilots?, return position. */
                return pos;
        }
    } else {    /* Pilot/sync are BYTE values... */
        if (readttbyte(pos, lp, sp, tp, en) == pv) {    /* got pilot byte? */
            z = 0;
            while(readttbyte(pos, lp, sp, tp, en) == pv && pos < tap.len) { /* skip all pilot bytes.. */
                z++;
                pos += 8;
            }

            if (z == 0)
                return 0;

            if (z < pmin || z > pmax)   /* too few/many pilots?, return position as negative. */
                return -pos;

            if (z >= pmin && z <= pmax) /* enough pilots?, return position. */
                return pos;
        }
    }

    return 0;       /* never reached. */
}

/**
 * Load the named tap file into buffer (tap.tmem[])
 *
 * @param name  Name of the tap file to load
 *
 * @return 1 on success
 * @return 0 on error.
 */

int load_tap(char *name)
{
    FILE *fp;
    int flen;

    fp = fopen(name, "rb");
    if (fp == NULL) {
        msgout("\nError: Couldn't open file in load_tap().");
        return 0;
    }

    /* First erase all stored data for the loaded 'tap', free buffers,
       and reset database entries */
    unload_tap();

    /* Read file size */
    fseek(fp, 0, SEEK_END);
    flen = ftell(fp);
    rewind(fp);

    /* Allocate enough space to load the file into */
    tap.tmem = (unsigned char*)malloc(flen);
    if(tap.tmem == NULL) {
        msgout("\nError: malloc failed in load_tap().");
        fclose(fp);
        return 0;
    }

    /* Load data into buffer */
    fread(tap.tmem, flen, 1, fp);
    fclose(fp);
    if(gain)
    {
    	int i;
    	for( i = 20; i< flen; )
        {
        	if(tap.tmem[i]>9) /* iAN: lower values are pauses */
            	tap.tmem[i++]+=gain;
            else
            	i+=4;
        }
    }

    /* Set the 'tap' structure file length subfield */
    tap.len = flen;


    /* the following were uncommented in GUI app..
     * these now appear in main()...
     * tol=DEFTOL;        reset tolerance..
     * debugmode=FALSE;  reset "debugging" mode.
     */


    /* If desired, preserve loader table between TAPs... */
    if (preserveloadertable == FALSE)
        reset_loader_table();

    /* Makes sure the tap is fully scanned afterwards. */
    tap.changed = TRUE;

    /* Reset this so cbm parts decode for a new tap
       (but NOT during same tap) */
    cbm_decoded = FALSE;

    /* Set the 'tap' structure file path and name subfields */
    strcpy(tap.path, name);
    getfilename(tap.name, name);

    return 1;       /* 1 = loaded ok */
}

/**
 * Perform a full analysis of the tap file
 *
 * Gather all available info from the tap. most data is stored in the 'tap' struct.
 *
 * Text output for pulse and file stats are written to str_pulses[] & str_files[] (global char arrays)
 * Note: this text output is created for the benefit of batchmode. (which doesnt call report()).
 *
 * Return 0 if file is not a valid TAP, else 1.
 */

int analyze(void)
{
    double per;

    if (tap.tmem == NULL)
        return 0;       /* no tap file loaded */

    tap.fsigcheck = check_signature();
    tap.fvercheck = check_version();
    tap.fsizcheck = check_size();

    if (tap.fsigcheck == 1 && tap.fvercheck == 1 && tap.fsizcheck == 1) {
        msgout("\nError: File is not a valid C64 TAP.");        /* all header checks failed */
        return 0;
    }

    tap.taptime = get_duration(20, tap.len);

    /* now call search_tap() to fill the file database (blk) */
    /* + call describe_blocks() to extract data and get checksum info. */

    note_errors = FALSE;
    search_tap();
    note_errors = TRUE;
    describe_blocks();
    note_errors = FALSE;

    /* Gather statistics... */

    tap.purity = get_pulse_stats();     /* note: saves unique pulse count */
    get_file_stats();

    tap.optimized_files = count_opt_files();
    tap.total_checksums_good = count_good_checksums();
    tap.detected = count_rpulses();
    tap.bootable = count_bootparts();

    /* compute % recognised... */

    per = ((double)tap.detected / ((double)tap.len - 20)) * 100;
    tap.detected_percent = (int)floor(per);

    /* Compute & store quality checks... */

    if (tap.fsigcheck == 0 && tap.fvercheck == 0 && tap.fsizcheck == 0)
        tap.tst_hd = 0;
    else
        tap.tst_hd = 1;

    if (tap.detected == (tap.len - 20))
        tap.tst_rc = 0;
    else
        tap.tst_rc = 1;

    if (tap.total_checksums_good == tap.total_checksums)
        tap.tst_cs = 0;
    else
        tap.tst_cs = 1;

    if (tap.total_read_errors == 0)
        tap.tst_rd = 0;
    else
        tap.tst_rd = 1;

    if (tap.total_data_files - tap.optimized_files == 0)
        tap.tst_op = 0;
    else
        tap.tst_op = 1;

    tap.crc = compute_overall_crc();
/* from 0.21, move makeprgs to end of report
    if (doprg == TRUE) {
        make_prgs();
        save_prgs();
    }
*/
    return 1;
}

/*
 * Save a report for this TAP file.
 * Note: Call 'analyze()' before calling this!.
 */

void report(void)
{
    int i;
    FILE *fp;
    char *rbuf;

    if(useprgdir>0)
    {
        char *p;
        strcpy(tcreportname,tap.name);
        p=strrchr(tcreportname,'.'); if(p) *p=0;
        strcat(tcreportname,"_tcreport.txt");
    }

    rbuf = (char*)malloc(INFOSIZE);
    if (rbuf == NULL) {
        msgout("\nError: malloc failed in report().");
        exit(1);
    }

    chdir(exedir);

    fp = fopen(temptcreportname, "r");      /* delete any existing temp file... */
    if (fp != NULL) {
        fclose(fp);
        remove(temptcreportname);
    }

    fp = fopen(tcreportname, "r");          /* delete any existing report file... */
    if (fp != NULL) {
        fclose(fp);
        remove(tcreportname);
    }

    fp = fopen(temptcreportname, "w+t");    /* create new report file... */

    if (fp != NULL) {

        /* include results and general info... */

        print_results(rbuf);
        fprintf(fp, rbuf);
        fprintf(fp, "\n" /* "\n\n\n\n\n"*/);

        /* include file stats... */

        print_file_stats(rbuf);
        fprintf(fp, rbuf);
        fprintf(fp, "\n" /* "\n\n\n\n\n"*/);

        /* include database in the file (partially interpreted)... */

        print_database(rbuf);
        fprintf(fp, rbuf);
        fprintf(fp, "\n" /* "\n\n\n\n\n"*/);

        /* include pulse stats in the file... */

        print_pulse_stats(rbuf);
        fprintf(fp, rbuf);
        fprintf(fp, "\n" /* "\n\n\n\n\n"*/);

        /* include 'read errors' report in the file... */

        if (tap.total_read_errors != 0) {
            fprintf(fp, "\n * Read error locations (Max %d)", NUM_READ_ERRORS);
            fprintf(fp, "\n");
            for (i = 0; read_errors[i] != 0; i++)
                fprintf(fp, "\n0x%04X", read_errors[i]);
            fprintf(fp, "\n\n" /* "\n\n\n\n\n"*/);
        }
        fclose(fp);
        rename(temptcreportname, tcreportname);
    } else
        msgout("\nError: failed to create report file.");

    /* show results and general info onscreen... */

    print_results(rbuf);

    if (!batchmode)
        fprintf(stdout, rbuf);

    free(rbuf);
/* from 0.21, move makeprgs to end of report*/
    if (doprg == TRUE) {
        make_prgs();
        save_prgs();
    }
}

/*
 * Calls upon functions found in clean.c to optimize and
 * correct the TAP.
 */

void clean(void)
{
    int x;

    if (tap.tmem == NULL) {
        msgout("\nError: No TAP file loaded!.");
        return;
    }

    if(debug) {
        msgout("\nError: Optimization is disabled whilst in debugging mode.");
        return;
    }

    quiet = 1;      /* no talking between search routines and worklog */

    convert_to_v0();    /* unpack pauses to V0 format if not already */
    clip_ends();        /* clip leading and trailing pauses */
    unify_pauses();     /* connect/rebuild any consecutive pauses */
    clean_files();      /* force perfect pulsewidths on known blocks */
    convert_to_v1();    /* repack pauses (v1 format) */

    fill_cbm_tone();    /* presently fills any gap of around 80 pulses   */
                /* (following a CBM block) with ft[CBM_HEAD].sp's. */

    /* this loop repairs pilot bytes and small gaps surrounding pauses, if
     * any pauses are inserted by 'insert_pauses()' then new gaps and pilots
     * may be identified in which case we repeat the loop until they are all
     * dealt with.
     */
    do {
        fix_pilots();       /* replace broken pilots with new ones. */
        fix_prepausegaps(); /* fix all pre pause "spike runs" of 1 2 or 3. */
        fix_postpausegaps();    /* fix all post pause "spike runs" of 1 2 or 3. */
        x = insert_pauses();    /* insert pauses between blocks that need one. */
    } while(x);

    standardize_pauses();       /* standardize CBM HEAD -> CBM PROG pauses. */
    fix_boot_pilot();       /* add new $6A00 pulse pilot on a CBM boot header. */
    cut_postdata_gaps();        /* cuts post-data gaps <20 pulses. */

    if (noaddpause == FALSE)
        add_trailpause();   /* add a 5 second trailing pause   */

    if(cuttrailunrec)       /* iAN CooG: cut last block if unrecognized */
        cut_trailing_unrecognized_block();

    fix_bleep_pilots();     /* correct any corrupted bleepload pilots */

    msgout("\n");
    msgout("\nCleaning finished.");
    quiet = 0;          /* allow talking again. */
}

/*
 * Check whether the offset 'x' is accounted for in the database (by a data file
 * or a pause, not a gap), return 1 if it is, else 0.
 */

int is_accounted(int x)
{
    int i;

    for (i = 0; blk[i]->lt != 0; i++) {
        if (blk[i]->lt != GAP) {
            if ((x >= blk[i]->p1) && (x <= blk[i]->p4))
                return 1;
        }
    }

    return 0;
}

/*
 * Checks whether location 'p' is inside a pause. (harder than it sounds!)
 * Return 1 if it is, 0 if not.
 * Returns -1 if index is out-of-bounds
*/

int is_pause_param(int p)
{
    int i, z, pos;

    if (p < 20 || p > tap.len - 1)  /* p is out of bounds  */
        return -1;

    if (tap.tmem[p] == 0)       /* p is pointing at a zero! */
        return 1;

    if (tap.version == 0)       /* previous 'if' would have dealt with v0. the rest is v1 only */
        return 0;

    if (p < 24) {           /* test very beginning of TAP file, ensures no rewind into header! */
        if (tap.tmem[20] == 0)
            return 1;
        else
            return 0;
    }

    pos = p - 4;            /* pos will be at least 20 */

    do {                /* find first 4 pulses containing no zeroes (behind p)... */
        z = 0;
        for (i = 0; i < 4; i++) {
            if(tap.tmem[pos + i] == 0)
                z++;
        }
        if (z != 0)
            pos--;
    } while(z != 0 && pos > 19);


    if (z == 0) {           /* if TRUE, we found the first 4 containing no zeroes (behind p) */
        pos += 4;       /* pos now points to first v1 pause (a zero)  */

        /* ie.      xxxxxxxxxxx 0xx0 00xx 0x0x x 0x0x 00xx */
        /*              ^=pos      ^ = p */

        for (i = pos; i < tap.len - 4 ; i++) {
            if (tap.tmem[i] == 0)   /* skip over v1 pauses */
                i += 3;
            else {
                if (i == p)
                    return 0;   /* p is not in a pause */

                if (i > p)
                    return 1;   /* p is in a pause */
            }
        }
    } else { /* luigi */
        for (i = 20; i < tap.len - 4 ; i++) {
            if (tap.tmem[i] == 0)   /* skip over v1 pauses */
                i += 3;
            else {
                if (i == p)
                    return 0;   /* p is not in a pause */

                if (i > p)
                    return 1;   /* p is in a pause */
            }
        }
    }
    /* luigi: This point can't be reached*/
    return 0; /* luigi: fake, here to avoid warning at compile time */
}

/*
 * search blk[] array for instance number 'num' of block type 'lt' and calls
 * 'xxx_describe_block' for that file (which decodes it).
 * this is for use by scanners which need to get access to data held in other files
 * ahead of describe() time.
 * returns the block number in blk[] of the matching (and now decoded) file.
 * on failure returns -1;
 *
 * NOTE : currently only implemented for certain file types.
 */

int find_decode_block(int lt, int num)
{
    int i, j;

    for (i = 0,j = 0; i < BLKMAX; i++) {
        if (blk[i]->lt == lt) {
            j++;
            if (j == num) {     /* right filetype and right instance number? */
                if (lt == CBM_DATA || lt == CBM_HEAD) {
                    cbm_describe(i);
                    return i;
                }

                if (lt == CYBER_F1) {
                    cyberload_f1_describe(i);
                    return i;
                }

                if (lt == CYBER_F2) {
                    cyberload_f2_describe(i);
                    return i;
                }
            }
        }
    }

    return -1;
}

/*
 * Add an entry to the 'read_errors[NUM_READ_ERRORS]' array...
 */

int add_read_error(int addr)
{
    int i;

    if (!note_errors)
        return -1;

    for (i = 0; i < NUM_READ_ERRORS; i++) {             /* reject duplicates.. */
        if (read_errors[i] == addr)
            return -1;
    }

    for (i = 0; read_errors[i] != 0 && i < NUM_READ_ERRORS; i++);   /* find 1st free slot.. */

    if (i < NUM_READ_ERRORS) {
        read_errors[i] = addr;
        return 0;
    }

    return -1;      /* -1 = error table is full */
}

/*
 * Displays a message.
 * I made this to quickly convert the method of text output from the windows
 * sources. (ie. popup message windows etc).
 */

void msgout(char *str)
{
    printf("%s", str);
}

/*
 * Search integer array 'buf' for occurrence of sequence 'seq'.
 * On success return offset of matching sequence.
 * On failure return -1.
 * Note : value XX (-1) may be used in 'seq' as a wildcard.
 */

int find_seq(int *buf, int bufsz, int *seq, int seqsz)
{
    int i, j, match;

    if (seqsz > bufsz)          /* buf must be larger or equal to seq */
        return -1;

    for (i = 0; i < bufsz - seqsz; i++) {
        if (buf[i] == seq[0]) {     /* match first number. */
            match = 0;
            for (j = 0; j < seqsz && (i + j) < bufsz; j++) {
                if (buf[i + j] == seq[j] || seq[j] == -1)
                    match++;
            }
            if (match == seqsz) /* whole sequence found?  */
                return i;
        }
    }

    return -1;
}

/*
 * Isolate the filename part of a full path+filename and store it in buffer *dest.
 */

void getfilename(char *dest, char *fullpath)
{
    int i, j, k;

    i = strlen(fullpath);
    for (j = i; j > 0 && fullpath[j] != SLASH; j--);

    /* rewind j to 0 or first slash.. */

    if (fullpath[j] == SLASH)
        j++;        /* skip over the slash */
    for (k = 0; j < i; j++)
        dest[k++] = fullpath[j];
    dest[k] = 0;

    return;
}

/*
 * convert PetASCII string to ASCII text string.
 * user provides destination storage string 'dest'.
 * function returns a pointer to dest so the function may be called inline.
 */

char* pet2text(char *dest, char *src)
{
    int i, lwr;
    char ts[500];
    unsigned char ch;

    lwr = 0;    /* lowercase off. */

    /* process file name... */

    strcpy(dest, "");
    for (i = 0; src[i] != 0; i++) {
        ch = (unsigned char)src[i];

        /* process CHR$ 'SAME AS' codes... */

        if (ch == 255)
            ch = 126;
        if (ch > 223 && ch < 255)   /* produces 160-190 */
            ch -= 64;
        if (ch > 191 && ch < 224)   /* produces 96-127 */
            ch -= 96;

        if (ch == 14)           /* switch to lowercase.. */
            lwr = 1;
        if (ch == 142)          /* switch to uppercase.. */
            lwr = 0;

        if (ch > 31 && ch < 128) {  /* print printable character... */
            if (lwr) {      /* lowercase?, do some conversion... */
                if (ch > 64 && ch < 91)
                    ch += 32;
                else if (ch > 96 && ch < 123)
                    ch -= 32;
            }

            sprintf(ts, "%c", ch);
            strcat(dest, ts);
        }
    }

    return dest;
}

/*
 * Trims trailing spaces from a string.
 */

void trim_string(char *str)
{
    int i, len;

    len = strlen(str);
    if (len > 0) {
        for (i = len - 1; str[i] == 32 && i > 0; i--)   /* nullify trailing spaces.  */
        str[i] = 0;
    }
}

/*
 * Pads the string 'str' with spaces so the resulting string is 'wid' chars long.
 */

void padstring(char *str, int wid)
{
    int i, len;

    len = strlen(str);
    if (len < wid) {
        for (i = len; i < wid; i++)
            str[i] = 32;
        str[i] = 0;
    }
}

/*
 * Converts an integer number of seconds to a time string of format HH:MM:SS.
 */

void time2str(int secs, char *buf)
{
    int h, m, s;

    h = secs / 3600;
    m = (secs- (h * 3600)) / 60;
    s = secs - (h * 3600) - (m * 60);
    sprintf(buf, "%02d:%02d:%02d", h, m, s);
}

/*
 * Remove all/any existing work files.
 */

void deleteworkfiles(void)
{
    FILE *fp;

    /* delete existing work files... */
    /* note: the fopen tests avoid getting any console error output. */

    fp = fopen(temptcreportname, "r");
    if (fp != NULL) {
        fclose(fp);
        remove(temptcreportname);
    }

    fp = fopen(tcreportname, "r");
    if (fp != NULL) {
        fclose(fp);
        remove(tcreportname);
    }

    fp = fopen(temptcbatchreportname, "r");
    if (fp != NULL) {
        fclose(fp);
        remove(temptcbatchreportname);
    }

    fp = fopen(tcbatchreportname, "r");
    if (fp != NULL) {
        fclose(fp);
        remove(tcbatchreportname);
    }

    fp = fopen(tcinfoname, "r");
    if (fp != NULL) {
        fclose(fp);
        remove(tcinfoname);
    }
}

