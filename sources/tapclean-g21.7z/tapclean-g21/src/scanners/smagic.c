/*---------------------------------------------------------------------------
  smagic.c
  iAN CooG/HF

  Part of project "Final TAP".

  A Commodore 64 tape remastering and data extraction utility.

  (C) 2001-2006 Stewart Wilson, Subchrist Software.



   This program is free software; you can redistribute it and/or modify it under
   the terms of the GNU General Public License as published by the Free Software
   Foundation; either version 2 of the License, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE. See the GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along with
   this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
   St, Fifth Floor, Boston, MA 02110-1301 USA


  Notes:-
Loader used by an old freeze cart, SMAGIC 2
Found in "Viking 11 tap.zip"
MSBF
sync bytes: $40 (many) $5a
00-01 start address
02-03 endaddress
data
1 byte xor checksum

short pulse/Bit 0: $16
long  pulse/Bit 1: $27

---------------------------------------------------------------------------*/

#include "../mydefs.h"
#include "../main.h"

#define HDSZ 4
#define MAXCBMBACKTRACE 0x2A00  /* max amount of pulses between turbo file and the
                                   'FIRST' instance of its CBM data block.
                                   The typical value is less than this one */
/*---------------------------------------------------------------------------
*/
void smagic_search(int xx_head)
{
    int i,cnt2,sof,sod,eod,eof,z,ldrtype=0,lastldr=0,nseq=0;
    int t,bufszh,bufszd,s,e,x,j;
    int cbmheader=0,cbmdata=0;
    unsigned int xinfo=0;
    unsigned char pat[32],hd[8];
    unsigned char *bufh=NULL,*bufd=NULL;
    int lp=0;
    int sp=0;
    int tp=0;
    int en=0;


    if(!quiet)
    {  msgout( MSGBLANK );

       switch(xx_head)
       {
       case SMAGIC2:
           msgout("  Smagic");
           break;
       case YOURCOM:
           msgout("  YourCommodore");
           break;
       }
    }
    cbmheader=1;
    cbmdata=1;

    for(i=20; i<tap.len-8; i++)
    {
        t= find_decode_block(CBM_HEAD,cbmheader);

        if(t!=-1)
        {
            if(blk[t]->p1 < i-MAXCBMBACKTRACE)
            {
                i--;
                cbmheader++;
                continue;
            }
        }

        if(t!=-1)
        {
            bufszh= blk[t]->cx;
            bufh= malloc(bufszh*sizeof(int));
            for(j=0; j<bufszh; j++)
                bufh[j]= blk[t]->dd[j];
        }
        else
        {
            /* there is no further cbmheader, let's get outta here*/
            goto getout;
        }
        i=blk[t]->p4;
        while(t!=-1)
        {
            t= find_decode_block(CBM_DATA,cbmdata);
            if(t!=-1)
            {
                if(blk[t]->p1 < i-MAXCBMBACKTRACE)
                {
                    cbmdata++;
                    continue;
                }
                break;
            }
        }

        if(t!=-1)
        {
            bufszd= blk[t]->cx;
            bufd= malloc(bufszd*sizeof(int));
            for(j=0; j<bufszd; j++)
                bufd[j]= blk[t]->dd[j];
        }
        else
        {
            /* there is no cbmdata, (weird) let's get outta here*/
            goto getout;
        }
        j=*(int*)(bufh+1);
        ldrtype=0;
        switch(j)
        {
        case 0x030402A7:
            if((*(int*)(bufh+0x15) == 0x20039520 ) && (xx_head==SMAGIC2))
            {
                ldrtype=SMAGIC2;
                lastldr=ldrtype;
                nseq=0x5A;
                if(!quiet)
                    msgout("\n  +Smagic2");
            }
            break;
        case 0x030402bc:
            if((*(int*)(bufh+0x15) == 0x20038720 ) && (xx_head==YOURCOM))
            {
                ldrtype=YOURCOM;
                lastldr=ldrtype;
                nseq=0x5A;
                if(!quiet)
                    msgout("\n  +YourCommodore");
            }
            break;
        default:
            ldrtype=0;
            break;
        }
        /* set new start point from end of this cbm data block anyway */
        i=blk[t]->p4;
        if(!ldrtype)
        {
            if (bufd){ free(bufd);bufd=NULL;}
            if (bufh){ free(bufh);bufh=NULL;}
            /* not a known header, retry from here */
            i--;
            cbmheader++;
            continue;
        }
        else
        {
            /* found something, start from here */
            lp=ft[ldrtype].lp;
            sp=ft[ldrtype].sp;
            tp=ft[ldrtype].tp;
            en=ft[ldrtype].en;
        }
        while ((z=find_pilot(i,ldrtype))<=0)
        {
            i++;
            if(i>=tap.len-8)
                break;
        }
        if(i>=tap.len-8)
            break;
        else
        {
            sof=i;
            i=z;
            /* sync = $40..+$5a */
            memset(pat,0,2);
            for(cnt2=0; cnt2<1; cnt2++)
            {
                pat[cnt2] = readttbyte(i+(cnt2*8), lp, sp, tp, en);
            }

            if( pat[0]==nseq )
            {
                i+=8;

                for(cnt2=0; cnt2<HDSZ; cnt2++)
                {
                    hd[cnt2]=readttbyte(i+(cnt2*8), lp, sp, tp, en);
                }
                s = hd[0]|(hd[1]<<8);
                e = hd[2]|(hd[3]<<8);
                e--;

                i+=(cnt2*8);
                sod=i;
                if(e>s)
                {
                    x=e-s;
                    eod=sod+(x*8);
                    eof=eod+8;
                    eof+=7;

                    if(eof > tap.len)
                        eof=tap.len-4;
                    xinfo=s|(e<<16);
                    addblockdef(ldrtype, sof,sod,eod,eof, xinfo);
                    xinfo=0;
                    i=eof;   /* optimize search */
                    /*
                    now search next cbmheader
                    */
                    if (bufd){ free(bufd);bufd=NULL;}
                    if (bufh){ free(bufh);bufh=NULL;}

                    cbmheader+=2;

                }
            }

        }
    }
getout:
    if(!quiet&&lastldr)
        msgout("\n");

    if (bufd){ free(bufd);bufd=NULL;}
    if (bufh){ free(bufh);bufh=NULL;}
}
/*---------------------------------------------------------------------------
*/
int smagic_describe(int row)
{
    int i,s;
    int b,cb,rd_err;
    int ldrtype=blk[row]->lt;
    int lp=ft[ldrtype].lp;
    int sp=ft[ldrtype].sp;
    int tp=ft[ldrtype].tp;
    int en=ft[ldrtype].en;

    /* compute C64 start address, end address and size...  */

    blk[row]->cs =  blk[row]->xi        & 0xFFFF;
    blk[row]->ce = (blk[row]->xi >> 16) & 0xFFFF;

    blk[row]->cx = (blk[row]->ce - blk[row]->cs) + 1;
    /* get pilot trailer lengths...  */
    blk[row]->pilot_len= (blk[row]->p2- blk[row]->p1 -8) >>3;
    blk[row]->trail_len= (blk[row]->p4- blk[row]->p3 -7) >>3;

    /* extract data... */
    rd_err=0;
    s= (blk[row]->p2);
    cb=0;
    if(blk[row]->dd!=NULL)
        free(blk[row]->dd);
    blk[row]->dd = (unsigned char*)malloc(blk[row]->cx);

    for(i=0; i<blk[row]->cx; i++)
    {
        b=readttbyte(s+(i*8), lp, sp, tp, en);
        if(b==-1)
        {
            rd_err++;
            /* for experts only */
            sprintf(lin, "\n - Read Error on byte @$%X (prg data offset: $%04X)", s + (i * 8), i);
            strcat(info, lin);

        }

        cb^=b;

        blk[row]->dd[i]= b;
    }
    blk[row]->cs_exp= readttbyte(s+(i*8), lp, sp, tp, en);
    blk[row]->cs_act= cb &0xFF;

    blk[row]->rd_err= rd_err;
    return 0;

}

