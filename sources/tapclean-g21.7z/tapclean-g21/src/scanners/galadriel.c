/*---------------------------------------------------------------------------
  turbotape_galdriel.c
  derived from turbotape.c & anirog.c, iAN CooG/HF

  Part of project "Final TAP".

  A Commodore 64 tape remastering and data extraction utility.

  (C) 2001-2006 Stewart Wilson, Subchrist Software.



   This program is free software; you can redistribute it and/or modify it under
   the terms of the GNU General Public License as published by the Free Software
   Foundation; either version 2 of the License, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE. See the GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along with
   this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
   St, Fifth Floor, Boston, MA 02110-1301 USA

*/
/*
Notes:-

26/07/07 iAN: started to implement based on the following information

BITURBO BY SC 85
----------------
Threshold: $0107 clock cycles (TAP value: $21)
Bit 0 pulse: $1B
Bit 1 pulse: $27
Endianess: MSbF

Pilot byte: $02 (x496)
Sync sequence: $10, $0F, ... $01
1 byte: ignored

Hardcoded inside CBM Header block:
    $0305: Load address (LSB)
    $0317: Load address (MSB)
    $0313: End address (LSB)
    $030C: End address (MSB)

Data

1 byte: XOR checksum

Trailer: bit 0 pulses (x2040 about)

1 hack found, 4 headers instead of 2 header + 2 data
    $2b/2c : Load address ($0801 fixed)
    $02BC/$02BD :End address

...and more findings in other similar loaders
*/

/* "bob85" (dylandog:murderers) */
/* find pilot $02
find $10...$01($00) sequence
readtbyte->sod.low
readtbyte->sod.hi
readtbyte->eod.low
readtbyte->eod.hi
readtbyte->(startadr-1).hi
readtbyte->(startadr-1).low
*/

/*
"poke" wrongly detected as anirog but has at least one difference
find pilot $02 but NO SYNC
find $09...$01 sequence
readtbyte->sod.low
readtbyte->sod.hi
readtbyte->eod.low
readtbyte->eod.hi
readtbyte->(startadr).hi
readtbyte->(startadr).low
(+push Y)?
*/

/*
reversed bit order version of poke, found in "17A SIDE A.tap" "17A SIDE B.tap" (algasoft/softhome? dunno)
find pilot $02 but NO SYNC
find $09...$01 sequence
readtbyte->sod.low
readtbyte->sod.hi
readtbyte->eod.low
readtbyte->eod.hi

2 hacks found with different cbm_header, but same stuff inside
*/

/*---------------------------------------------------------------------------*/

#include "../mydefs.h"
#include "../main.h"

#define LEAD 0x02
#define SYNC 0x10
#define HDSZ 6
#define MAXCBMBACKTRACE 0x2A00  /* max amount of pulses between turbo file and the
                                   'FIRST' instance of its CBM data block.
                                   The typical value is less than this one */

/*---------------------------------------------------------------------------
*/
void galadriel_search(void)
{
    int i,cnt2,sof,sod,eod,eof,z,ldrtype,lastldr=0,nseq=0;
    int t,bufszh,bufszd,s=0,e=0,x=0,j=0;
    int xorval=0,xorstart=0,xorend=0,jmpaddr=0;
    int cbmheader=0,cbmdata=0;
    int blackhawkdetected=0;
    int new_s=0,new_e=0;
    unsigned int xinfo=0;
    unsigned char byt,pat[32],hd[HDSZ];
    unsigned char *bufh=NULL,*bufd=NULL;
    int lp=0;
    int sp=0;
    int tp=0;
    int en=0;


    if(!quiet)
    {   msgout( MSGBLANK );
        msgout("  Galadriel (& clones)");
    }
    /* scan the tape finding the 1st cbmheader containing a galadriel */
    cbmheader=1;
    cbmdata=1;

    for(i=20; i<tap.len-8; i++)
    {
        t= find_decode_block(CBM_HEAD,cbmheader);

        if(t!=-1)
        {
            if(blk[t]->p1 < i-MAXCBMBACKTRACE)
            {
                i--;
                cbmheader++;
                continue;
            }
        }

        if(t!=-1)
        {
            bufszh= blk[t]->cx;
            bufh= malloc(bufszh*sizeof(int));
            for(j=0; j<bufszh; j++)
                bufh[j]= blk[t]->dd[j];
        }
        else
        {
            /* there is no further cbmheader, let's get outta here*/
            goto getout;
        }
        i=blk[t]->p4;
        while(t!=-1)
        {
            t= find_decode_block(CBM_DATA,cbmdata);
            /* galadriel_4 hack */
            if(t==-1)
            {
                if( (*(int *)(bufh+0x01)==0x032c02BA) && (*(int *)(bufh+0x15)==0xC9CA0AAD) )
                {
                    t= find_decode_block(CBM_HEAD,cbmheader+2);
                }

            }
            /* galadriel_4 hack end */
            if(t!=-1)
            {
                if(blk[t]->p1 < i-MAXCBMBACKTRACE)
                {
                    cbmdata++;
                    continue;
                }
                break;
            }
        }

        if(t!=-1)
        {
            bufszd= blk[t]->cx;
            bufd= malloc(bufszd*sizeof(int));
            for(j=0; j<bufszd; j++)
                bufd[j]= blk[t]->dd[j];
        }
        else
        {
            /* there is no cbmdata, (weird) let's get outta here*/
            goto getout;
        }
        j=*(int*)(bufh+1);
        ldrtype=0;
        switch(j)
        {
        case 0x032c02ba:
            ldrtype=GALADRIEL;
            lastldr=ldrtype;
            nseq=0x10;
            j&=0xffff;
            if((*(int *)(bufh+0x15)==0xC9CA0AAD) &&
               (*(int *)(bufd+0x09)==0x8502BDAD)
              )
            {
                /* gets start address from $2b/2c and end address from $02bc/d
                */
                s = 0x0801; /* bufd[0x0]|(bufd[0x1]<<8); in theory, but assumes 0801 fixed in code */
                e = bufd[0x2]|(bufd[0x3]<<8);
                if(!quiet)
                    msgout("\n  +Galadriel/4h");
            }
            else
            {
                s = bufd[0x305-j]|(bufd[0x317-j]<<8);
                e = bufd[0x313-j]|(bufd[0x30c-j]<<8);
                jmpaddr  = (*(unsigned short int *)&bufd[0x02BA-j])+1;
                if(!quiet)
                {
                    if(bufh[0x15]==0xad)
                        msgout("\n  +Galadriel/5");
                    else
                    {
                        msgout("\n  +Galadriel '");
                        bufh[0x25]=0;
                        msgout(bufh+0x15);
                        msgout("'");
                    }
                }
            }
            e--;
            xinfo = s + (e << 16);
            break;

        case 0x032c02a8:
            ldrtype=GALADRIEL_XOR;
            lastldr=ldrtype;
            nseq=0x10;
            j&=0xffff;

            s = bufd[0x305-j]|(bufd[0x317-j]<<8);
            e = bufd[0x313-j]|(bufd[0x30c-j]<<8);

            xinfo = s + (e << 16);

            xorval   = bufd[0x02F5-j];
            xorstart = bufd[0x02EF-j];
            xorend   = bufd[0x02AB-j];
            jmpaddr  = (*(unsigned short int *)&bufd[0x02BA-j])+1;

            if(!quiet)
                msgout("\n  +Galadriel/XOR");
            break;

        case 0x031A02A7:
            ldrtype=GALADRIEL_BOB85;
            lastldr=ldrtype;
            nseq=0x10;
            if(!quiet)
                msgout("\n  +Bob85");
            break;

        case 0x03050302:
            ldrtype=GALADRIEL_POKE;
            lastldr=ldrtype;
            nseq=0x09;
            if(!quiet)
                msgout("\n  +Poke/Golden");
            break;

        case 0x033C032C:
            ldrtype=GALADRIEL_REV;
            lastldr=ldrtype;
            nseq=0x09;
            if(!quiet)
                msgout("\n  +Poke/Rev");
            break;
        case 0x03040302:
            ldrtype=GALADRIEL_REV;
            lastldr=ldrtype;
            nseq=0x09;
            if(!quiet)
                msgout("\n  +Poke/Rev2");
            break;

        default:
            ldrtype=0;
            break;
        }
        /* set new start point from end of this cbm data block anyway */
        i=blk[t]->p4;
        if(!ldrtype)
        {
            if (bufd){ free(bufd);bufd=NULL;}
            if (bufh){ free(bufh);bufh=NULL;}
            /* not a known header, retry from here */
            i--;
            cbmheader++;
            continue;
        }
        else
        {
            /* found something, start from here */
            lp=ft[ldrtype].lp;
            sp=ft[ldrtype].sp;
            tp=ft[ldrtype].tp;
            en=ft[ldrtype].en;
        }

continue_from_here:
        while ((z=find_pilot(i,ldrtype))<=0)
        {
            i++;
            if(i>=tap.len-8)
                break;
        }
        if(i>=tap.len-8)
            break;
        else
        {
            sof=i;
            i=z;
            /* POKE&REV don't have a SYNC */
            if( ldrtype>=GALADRIEL_POKE ||
                readttbyte(i, lp, sp, tp, en)==nseq)  /* ending with a sync. */
            {
                for(cnt2=0; cnt2<=nseq; cnt2++)
                {
                    pat[cnt2] = readttbyte(i+(cnt2*8), lp, sp, tp, en);   /* decode a 0x10 byte sequence */
                }
                for(t=0;t<=nseq;t++)
                {
                    if((t<nseq)&&(pat[t]!=nseq-t))
                        break;
                }
                if( t>nseq )
                {
                    if(ldrtype>=GALADRIEL_POKE) /* POKE&REV don't have an extra byte*/
                        t--;
                    i=i+(t*8);
                    sod=i;
                    if(ldrtype>=GALADRIEL_BOB85)
                    {
                        for(cnt2=0; cnt2<HDSZ; cnt2++)
                        {
                            hd[cnt2]=readttbyte(i+(cnt2*8), lp, sp, tp, en);
                        }
                        s=(hd[5]|(hd[4]<<8));
                        if(ldrtype==GALADRIEL_BOB85)
                        {
                            s++;
                        }
                        if(ldrtype==GALADRIEL_REV)
                        {/* has only 4 byte header*/
                            cnt2-=2;
                            if( *(short unsigned int*)hd == 0xc000 ) /* check if we have blackhawk's 2nd galadriel at $c000 */
                            {
                                for(x=0; x<sizeof(pat);x++)
                                {
                                    pat[x]=readttbyte(i+(x+cnt2)*8, lp, sp, tp, en);
                                }
                                if( *(int*)pat == 0x288dE1A9 )
                                {
                                    if( (*(int*)(pat+5) & 0xffff00ff) == 0x268500A9 )
                                    {
                                        if     (*(short unsigned int*)(hd+2) == 0xc313) blackhawkdetected=1; // exception: nseq=0x10
                                        else if(*(short unsigned int*)(hd+2) == 0xc320) blackhawkdetected=2;
                                        else if(*(short unsigned int*)(hd+2) == 0xc340) blackhawkdetected=2;
                                        else if(*(short unsigned int*)(hd+2) == 0xc370) blackhawkdetected=2;
                                        else blackhawkdetected=0xff;
                                        new_s=pat[0x06]|pat[0x0a]<<8;
                                        new_e=pat[0x0e]|pat[0x12]<<8;
                                    }
                                    else if( *(int*)(pat+5) == 0x00b950a0 )
                                    {
                                        if(*(short unsigned int*)(hd+2) == 0xc320) blackhawkdetected=0x11;
                                        else blackhawkdetected=0xff;
                                    }
                                    else if( *(int*)(pat+0x1c)  == 0x03308d00 )
                                    {
                                       // change to easytape1
                                       blackhawkdetected=0x41;
                                    }
                                }
                            }
                        }
                        else
                        {
                            /* bob85 + Poke:
                            includes jump address in tcreport.txt using xinfo
                            */
                            xinfo=s;
                        }
                        s = hd[0]|(hd[1]<<8);
                        e = hd[2]|(hd[3]<<8);

                        i=i+(cnt2*8);
                    }

                    if(e>s)
                    {
                        x=e-s-1;
                        eod=sod+(x*8);

                        if(ldrtype<GALADRIEL_POKE)
                        {
                            eof=eod+2000; /* hack: has about 255 trailing "0" bytes*/

                            while((byt=readttbyte(eof, lp, sp, tp, en))==0)
                            {
                                eof+=8;
                            }
                            eof--;
                            if (eof>tap.len)
                                eof=tap.len-4;
                        }
                        else
                        {
                            if(ldrtype==GALADRIEL_REV)
                                eof=eod+48;
                            else
                                eof=eod+55;
                        }
                        t=addblockdef(ldrtype, sof,sod,eod,eof, xinfo);
                        if(t>0)
                        {
                            /* galadriel+xor version:
                            use checksum ints as extra info about jmpaddr
                            and xor values. Both don't use checksums anyway
                            */
                            if(ldrtype<=GALADRIEL_XOR)
                            {
                                blk[t]->cs_exp = jmpaddr; /* use only if >=$0400 */

                                if(ldrtype==GALADRIEL_XOR)
                                {
                                    blk[t]->cs_act =( (xorval  <<24) |
                                                      (xorstart<<8 ) |
                                                      xorend );
                                }
                            }
                        }
                        xinfo=0;
                        i=eof;   /* optimize search */

                        if(blackhawkdetected)
                        {
                            if(blackhawkdetected>=0x1 && blackhawkdetected<=0x0f)
                            {
                                if(!quiet)
                                {
                                    sprintf(bufh,"\n  +Blackhawk/%d",blackhawkdetected);
                                    msgout(bufh);
                                }

                                /* 0x10 needed in one blackhawk's galadriel, the others use 0x0f */
                                if(blackhawkdetected==1)
                                    nseq=0x10;
                                else
                                    nseq=0x0f;
                                ldrtype=GALADRIEL;
                                lp=ft[ldrtype].lp;
                                sp=ft[ldrtype].sp;
                                tp=ft[ldrtype].tp;
                                en=ft[ldrtype].en;

                                s=new_s;
                                e=new_e;
                                e--;
                                xinfo = s + (e << 16);
                                blackhawkdetected=0;
                                goto continue_from_here;
                            }
                            else if (blackhawkdetected>=0x11 && blackhawkdetected<=0x1f)
                            {
                                if(!quiet)
                                {
                                    sprintf(bufh,"\n  +Blackhawk/Poke%d",blackhawkdetected&0x0f);
                                    msgout(bufh);
                                }
                                /**/
                                ldrtype=GALADRIEL_POKE1;
                                lp=ft[ldrtype].lp;
                                sp=ft[ldrtype].sp;
                                tp=ft[ldrtype].tp;
                                en=ft[ldrtype].en;
                                nseq=0x09;
                                i++;
                                blackhawkdetected=0;
                                goto continue_from_here;
                                /**/
                            }
                            else if (blackhawkdetected>=0x41 && blackhawkdetected<=0x7f)
                            {

                                if(!quiet)
                                {
                                    sprintf(bufh,"\n  +Blackhawk+Easytape/%d",blackhawkdetected&0x3f);
                                    msgout(bufh);
                                }
                                //ldrtype=EASYTAPE1;
                                bh_force_easy=i;
                                easykludge=TRUE;
                                easytape_search();
                                goto getout;


                            }
                            else
                            {
                                if(!quiet)
                                {
                                    sprintf(bufh,"\n  +UNKNOWN BLACKHAWK!\a");
                                    msgout(bufh);
                                }
                            }
                        }
                        /*
                        now search next cbmheader
                        */
                        if (bufd){ free(bufd);bufd=NULL;}
                        if (bufh){ free(bufh);bufh=NULL;}

                        if(ldrtype==GALADRIEL_BOB85)
                        {
                            if (find_decode_block(CBM_HEAD,cbmheader+2)==-1)
                                goto continue_from_here;
                            /* The rest are data files for the same loader.
                               If there are datas and another cbm f.e.
                               dylandog tape joined with something else,
                               well, STAP is your friend :P
                            */
                        }
                    }
                }
            }
        }
    }
getout:
    if(!quiet&&lastldr)
        msgout("\n");
    if (bufd){ free(bufd);bufd=NULL;}
    if (bufh){ free(bufh);bufh=NULL;}
}
/*---------------------------------------------------------------------------
*/
int galadriel_describe(int row)
{

    int i,s,off;
    int b,cb,hd[HDSZ],rd_err;
    int ldrtype=blk[row]->lt;
    int xorvalue=0;
    int xorstart=0;
    int xorend  =0;
    int lp=ft[ldrtype].lp;
    int sp=ft[ldrtype].sp;
    int tp=ft[ldrtype].tp;
    int en=ft[ldrtype].en;

    /* decode header... */
    s= blk[row]->p2;
    if(ldrtype>=GALADRIEL_BOB85)
    {
        if(ldrtype==GALADRIEL_REV)
            off=4;
        else
            off=HDSZ;
        for(i=0; i<off; i++)
            hd[i]= readttbyte(s+(i*8), lp, sp, tp, en);
        /* compute C64 start address, end address and size...  */
        blk[row]->cs = hd[0]+ (hd[1]<<8);
        blk[row]->ce = hd[2]+ (hd[3]<<8)-1;
    }
    else
    {
        /* Retrieve C64 memory location for load/end address from extra-info */
        blk[row]->cs =  blk[row]->xi        & 0xFFFF;
        blk[row]->ce = (blk[row]->xi >> 16) & 0xFFFF;
        off=0;

        if(ldrtype==GALADRIEL_XOR)
        {
            /* get decrypt parameters */
            xorvalue = blk[row]->cs_act>>24;
            xorstart = blk[row]->cs_act & 0xff00;
            xorend   =(blk[row]->cs_act & 0x00ff)<<8;
        }
    }
    blk[row]->cx = (blk[row]->ce - blk[row]->cs) + 1;
    /* get pilot trailer lengths...  */
    blk[row]->pilot_len= (blk[row]->p2- blk[row]->p1 -8) >>3;
    blk[row]->trail_len= (blk[row]->p4- blk[row]->p3 -7) >>3;

    /* extract data... */
    rd_err=0;
    s= (blk[row]->p2)+(off*8);
    cb=0;
    if(blk[row]->dd!=NULL)
        free(blk[row]->dd);
    blk[row]->dd = (unsigned char*)malloc(blk[row]->cx);

    for(i=0; i<blk[row]->cx; i++)
    {
        b= readttbyte(s+(i*8), lp, sp, tp, en);
        if(b==-1)
        {
            rd_err++;
            /* for experts only */
            sprintf(lin, "\n - Read Error on byte @$%X (prg data offset: $%04X)", s + (i * 8), i);
            strcat(info, lin);

        }
        if(ldrtype==GALADRIEL_REV)
            cb+=b;
        else
            cb^=b;

        blk[row]->dd[i]= b;

        if(ldrtype==GALADRIEL_XOR)
        {
            if(blk[row]->cs+i >= xorstart && blk[row]->cs+i < xorend )
                blk[row]->dd[i] ^= xorvalue;
        }
    }
    if(ldrtype > GALADRIEL_XOR)
    {
        b= readttbyte(s+(i*8), lp, sp, tp, en);
        blk[row]->cs_exp= cb &0xFF;
        blk[row]->cs_act= b;
    }
    blk[row]->rd_err= rd_err;
    return 0;

}

