/*---------------------------------------------------------------------------
  turbotape.c

  Part of project "Final TAP".

  A Commodore 64 tape remastering and data extraction utility.

  (C) 2001-2006 Stewart Wilson, Subchrist Software.



   This program is free software; you can redistribute it and/or modify it under
   the terms of the GNU General Public License as published by the Free Software
   Foundation; either version 2 of the License, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE. See the GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along with
   this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
   St, Fifth Floor, Boston, MA 02110-1301 USA


  Notes:-

  9/12/2001 - added trailer tracing, only 1 tap i found so far actually has trailers.
            - pilot/trailer length calc is 100%.


this one is dealt with a bit specially, it has separate headers for each program block,
the header size is variable, so needs special location technique, the following program
block has to be located by looking at the size in the header.

the upshot is that the blocks come in pairs, and they must be located in pairs also...

first a header is located properly, then a program block is searched for, it MUST be
within 100 pulses from the tail end of the header for the pair to qualify.


further notes:-

 - only BASIC type program blocks have an ID byte in front of them
------------------------------------------------------------------------
Merged with Load'n'Run loader by iAN CooG/HF

  Loader found in
  "COM 64 - load'n'run"
  "Turbo64 1: T64N1A.TAP"
  Edisoft's "Next" "Next Game" "Next Strategy"
  jackson's "7note bit"

  MSBF
  sp=0x32
  lp=0x4d
  threshold=0x3d (approx)

  pilot= 0x02 (many)
  sync = 9...1
  $c0 bytes loaded at $033c
  {
    0..1: start address
    2..3: end address
    4   : dunno
    rest = 0x20 filler
  }
  pilot= 0x02 (many)
  sync = 9...1
  (end-start)bytes: actual file
  {
    xor checksum
  }
  last byte: expected checksum

Added also 7notebit
  MSBF
  sp=0x29
  lp=0x43
  threshold=0x36 (approx)
---------------------------------------------------------------------------*/

#include "../mydefs.h"
#include "../main.h"

#define LEAD 0x02
#define SYNC 0x09
#define HDSZ 21

/*---------------------------------------------------------------------------
*/
void turbotape_search(int xx_head)
{
   int i,cnt2,sof,sod,eod,eof,zcnt,z,hsize,psize,lastldr=0;
   unsigned char byt,pat[32],p,hd[HDSZ];
   int xx_data=xx_head+1;
   int lp=ft[xx_head].lp;
   int sp=ft[xx_head].sp;
   int tp=ft[xx_head].tp;
   int en=ft[xx_head].en;

   if(!quiet)
    {  msgout( MSGBLANK );
       switch(xx_head)
       {
       case TT_HEAD:
           msgout("  Turbotape 250 (+clones)");
           break;
       case NEXT_HEAD:
           msgout("  Next");
           break;
       case LOADNRUN_HEAD:
           msgout("  Load'N'Run");
           break;
       case NOTEBIT_HEAD:
           msgout("  7Note Bit");
           break;
       }
    }

   for(i=20; i<tap.len-8; i++)
   {
      if((z=find_pilot(i,xx_head))>0)
      {
         sof=i;
         i=z;
         if(readttbyte(i, lp, sp, tp, en)==SYNC)  /* ending with a sync. */
         {
            for(cnt2=0; cnt2<SYNC; cnt2++)
               pat[cnt2] = readttbyte(i+(cnt2*8), lp, sp, tp, en);   /* decode a 10 byte sequence */

            for(z=0;z<SYNC;z++)
            {
                if(pat[z]!=SYNC-z)
                    break;
            }
            if( z==SYNC )
            {
               sod = i+72;  /* sod points to start of ID byte */

               /* decode the first byte to see if its a header or a data block... */
               byt = readttbyte(sod, lp, sp, tp, en);

			   /* french TT workaround */
			   if(byt == 0x61 || byt == 0x62 )
			   	   byt &= 3;

               if(byt==1 || byt==2)  /* it's a header... */
               {
                  /* decode first few so we can get the program size (needed later)... */
                  for(cnt2=0; cnt2<8; cnt2++)
                     hd[cnt2] = readttbyte(sod+(cnt2*8), lp, sp, tp, en);
                  psize = (hd[3]+(hd[4]<<8)) - (hd[1]+(hd[2]<<8)) +1; /*  end addr - start addr. */

                  /* now scan through any 0x20's after the used header bytes... (to find its end) */
                  zcnt=22;
                  if(readttbyte(sod+(zcnt*8), lp, sp, tp, en)==0x20)
                  {
                     do
                     {
                        byt = readttbyte(sod+(zcnt*8), lp, sp, tp, en);
                        zcnt++;
                     }
                     while(byt==0x20);

                     zcnt--;
                     eod = sod+(zcnt*8)-8;
                     eof = eod+7;  /* prepare for poss override. */

                     hsize = (float)((eod+1) - sod)/8;
                     addblockdef(xx_head, sof,sod,eod,eof, hsize);
                     i = sod+(zcnt*8);  /* optimize search */

                     /* now look for the corresponding program block... */
                     zcnt=0;
                     do        /* find a new lead... */
                     {
                        byt = readttbyte(i, lp, sp, tp, en);
                        i++;
                        zcnt++;  /* this records the distance travelled to the prog, must be limited */
                     }
                     while(byt!=LEAD && i<tap.len-8);
                     i--;

                     if(byt==LEAD && zcnt<100)    /* less than 100 pulses travelled to this? */
                     {
                        sof = i;
                        zcnt=0;
                        do    /* trace to its end.. */
                        {
                           byt = readttbyte(i, lp, sp, tp, en);
                           i+=8;
                           zcnt++;  /* count leader length (bytes) */
                        }
                        while(byt==LEAD && i<tap.len);

                        if(zcnt>50 && byt==SYNC)  /* if it ends with a sync... */
                        {
                           byt = readttbyte(i+64, lp, sp, tp, en);
                           if(byt==0)  /* we can now assume its a prog block. */
                           {
                               if(!quiet)
                               {
                                   switch(xx_head)
                                   {
                                   case TT_HEAD:
                                       msgout("\n  +TT250");
                                       lastldr=xx_head;
                                       break;
                                   case NEXT_HEAD:
                                       msgout("\n  +Next");
                                       lastldr=xx_head;
                                       break;
                                   case LOADNRUN_HEAD:
                                       msgout("\n  +L'n'R");
                                       lastldr=xx_head;
                                       break;
                                   case NOTEBIT_HEAD:
                                       msgout("\n  +7NoteBit");
                                       lastldr=xx_head;
                                       break;
                                   }
                               }

                              sod = i+64;
                              eod = sod+(psize*8); /* see psize calculation above */
                              eof=eod+7;

                              if(eof<tap.len) /* this fixes a crash. where psize is wrong. */
                              {
                                 /* now trace to end of trailer (if exists)... */
                                 p = tap.tmem[eof+1];
                                 if(p>sp-tol && p<sp+tol)
                                 {
                                    do
                                       eof++;
                                    while(tap.tmem[eof+1]>sp-tol && tap.tmem[eof+1]<sp+tol && eof<tap.len);
                                 }
                                 addblockdef(xx_data, sof,sod,eod,eof,0);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }
   if(!quiet&&lastldr)
       msgout("\n");
}
/*---------------------------------------------------------------------------
*/
int turbotape_describe(int row)
{
   int i,s;
   int type,b,rd_err,cb;
   int hd[HDSZ+1];  /* +1 coz I save the ID byte here too */
   char ftype[32];
   char fn[256];
   char str[2000];
   int xx_head=blk[row]->lt;
   int lp=ft[xx_head].lp;
   int sp=ft[xx_head].sp;
   int tp=ft[xx_head].tp;
   int en=ft[xx_head].en;

   static int _db_start=0,_db_end=0; /* DATA BLOCK start/end addresses
                                         these are set by header block describe
                                         for use by a following data block describe. */

   /* decode the first few bytes to determine block type... */
   s= blk[row]->p2;
   for(i=0; i<HDSZ; i++)
      hd[i]= readttbyte(s+(i*8), lp, sp, tp, en);

   /* display filetype */
   type= hd[0];

   /* french TT workaround */
   if(type==0x61||type==0x62)
	  type &= 3;

   if(type==0)
      strcpy(ftype,"DATA");
   if(type==1)
      strcpy(ftype,"HEADER (DATA is BASIC)");
   if(type==2)
      strcpy(ftype,"HEADER (DATA is Binary)");
   sprintf(lin,"\n - Block type: %s (ID=$%02X)",ftype, type);
   strcat(info,lin);

   /*------------------------------------------------------------------------------*/
   if(type==1 || type==2)  /* its a HEADER file... */
   {
      /* compute C64 start address, end address and size... */
      blk[row]->cs= 0x033C;
      blk[row]->cx= (blk[row]->p3 - blk[row]->p2)>>3;
      blk[row]->ce= (blk[row]->cs + blk[row]->cx) -1;

      _db_start = hd[1]+ (hd[2]<<8);  /* static save start address of DATA block */
      _db_end = hd[3]+ (hd[4]<<8);    /* static save end address of DATA block */

      sprintf(lin,"\n - DATA FILE load address: $%04X", _db_start);
      strcat(info,lin);
      sprintf(lin,"\n - DATA FILE end address: $%04X", _db_end);
      strcat(info,lin);

      /* extract file name... */
      for(i=0; i<16; i++)
         fn[i]= hd[6+i];
      fn[i]=0;
      trim_string(fn);
      pet2text(str,fn);

      if(blk[row]->fn!=NULL)
         free(blk[row]->fn);
      blk[row]->fn = (char*)malloc(strlen(str)+1);

      strcpy(blk[row]->fn, str);

      sprintf(lin,"\n - Header size: %d bytes", blk[row]->xi);
      strcat(info,lin);
   }
   /*------------------------------------------------------------------------------*/
   if(type==0)   /* its a DATA file... */
   {
      /* compute C64 start address, end address and size... */
      blk[row]->cs= _db_start;    /* (recalled from previous header) */
      blk[row]->ce= _db_end;
      blk[row]->cx= _db_end - _db_start;
   }

   /* common code for both headers and data files... */

   /* get pilot trailer lengths... */
   blk[row]->pilot_len= blk[row]->p2- blk[row]->p1 -80;
   blk[row]->trail_len= blk[row]->p4- blk[row]->p3 -7;

   /* extract data and test checksum... */
   rd_err=0;
   cb=0;
   s= (blk[row]->p2)+8; /* +8 skips ID byte */

   if(blk[row]->dd!=NULL)
      free(blk[row]->dd);
   blk[row]->dd = (unsigned char*)malloc(blk[row]->cx);

   for(i=0; i<blk[row]->cx; i++)
   {
      b= readttbyte(s+(i*8), lp, sp, tp, en);
      cb^=b;
      if(b==-1)
         rd_err++;
      blk[row]->dd[i]=b;
   }
   b= readttbyte(s+(i*8), lp, sp, tp, en); /* read actual cb. */
   blk[row]->cs_exp= cb &0xFF;
   blk[row]->cs_act= b;
   blk[row]->rd_err= rd_err;

   if((xx_head==TT_HEAD)      ||
      (xx_head==NEXT_HEAD)    ||
      (xx_head==NOTEBIT_HEAD) ||
      (xx_head==LOADNRUN_HEAD) )
      blk[row]->cs_exp = -2;   /* headers dont use checksums. */

   return 0;
}

