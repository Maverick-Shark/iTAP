/*---------------------------------------------------------------------------
  freezeframe.c
  derived from turbotape_easytape.c, iAN CooG/HF

  Part of project "Final TAP".

  A Commodore 64 tape remastering and data extraction utility.

  (C) 2001-2006 Stewart Wilson, Subchrist Software.



   This program is free software; you can redistribute it and/or modify it under
   the terms of the GNU General Public License as published by the Free Software
   Foundation; either version 2 of the License, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE. See the GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along with
   this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
   St, Fifth Floor, Boston, MA 02110-1301 USA


  Notes:-


FF tape
-------

Used in:
"Addicta Ball", "Bug Bomber", "Football Manager", "Gremlin Pool", "Gremlin
Snooker", "Skateboard Joust" and "Turbo 64" (supplied by c64heaven).
Structure:
The boot CBM file (Filename "FF"; HEADER CRC32: 0x0E527A8B, but in "Bug
Bomber"; DATA loaded at $02C0-$0303, CRC32: 0xE356E438) contains the turbo
loader, where there's a load table with Load and End addresses of 2 turbo
blocks.
The first 2 turbo blocks are usually loaded at: $6000-$7400, $1400-$23E0.
Turbo blocks:
Threshold: 0x01A0 (416) clock cycles (TAP value: 0x34)
Bit 0 pulse: 0x28
Bit 1 pulse: 0x3F
Endianess: LSbF

Pilot bit: Bit 0 pulses (size: 2056 pulses about)
Sync  couple (bytes): 0x80, 0xAA

Data

Trailer: Bit 0 pulses (x2040 about)

---------------------------------------------------------------------------*/

#include "../mydefs.h"
#include "../main.h"

#define HDSZ 8
#define MAXCBMBACKTRACE 0x2A00  /* max amount of pulses between turbo file and the
                                   'FIRST' instance of its CBM data block.
                                   The typical value is less than this one */
/*---------------------------------------------------------------------------
*/
void ff_search(void)
{
    int i,cnt2,sof,sod,eod,eof,z=0,ldrtype=0,lastldr=0,nseq=0;
    int t,bufszh,bufszd,s=0,e=0,x=0,j=0;
    int cbmheader=0,cbmdata=0,nh=0,nd=0;
    unsigned int xinfo=0;
    unsigned char pat[32];
    unsigned char bufdata[0x10000];
    unsigned char *bufh=NULL,*bufd=NULL;
    int lp=0, sp=0, tp=0, en=0;


    if(!quiet)
    {   msgout( MSGBLANK );
        msgout("  FreezeFrame");
    }
    cbmheader=1;
    cbmdata=1;

    for(i=20; i<tap.len-8; i++)
    {
        t= find_decode_block(CBM_HEAD,cbmheader);

        if(t!=-1)
        {
            if(blk[t]->p1 < i-MAXCBMBACKTRACE)
            {
                i--;
                cbmheader++;
                continue;
            }
        }

        if(t!=-1)
        {
            bufszh= blk[t]->cx;
            bufh= malloc(bufszh*sizeof(int));
            for(j=0; j<bufszh; j++)
                bufh[j]= blk[t]->dd[j];
        }
        else
        {
            /* there is no further cbmheader, let's get outta here*/
            goto getout;
        }
        i=blk[t]->p4;
        while(t!=-1)
        {
            t= find_decode_block(CBM_DATA,cbmdata);
            if(t!=-1)
            {
                if(blk[t]->p1 < i-MAXCBMBACKTRACE)
                {
                    cbmdata++;
                    continue;
                }
                break;
            }
        }

        if(t!=-1)
        {
            bufszd= blk[t]->cx;
            bufd= malloc(bufszd*sizeof(int));
            for(j=0; j<bufszd; j++)
                bufd[j]= blk[t]->dd[j];
        }
        else
        {
            /* there is no cbmdata, (weird) let's get outta here*/
            goto getout;
        }
        j=(int)*(short int*)(bufh+1);
        ldrtype=0;
        switch(j)
        {
        case 0x02C0:
            ldrtype=FREEZEFRAME;
            lastldr=ldrtype;
            nseq=0xAA;
            if(!quiet)
                msgout("\n  +FF");
            nh=0;
            s=bufd[0x18]|bufd[0x1c]<<8;
            e=bufd[0x20]|bufd[0x24]<<8;
            e--;
            /* 1st block */
            break;
        default:
            ldrtype=0;
            break;
        }
        /* set new start point from end of this cbm data block anyway */
        i=blk[t]->p4;
        if(!ldrtype)
        {
            if (bufd){ free(bufd);bufd=NULL;}
            if (bufh){ free(bufh);bufh=NULL;}
            /* not a known header, retry from here */
            i--;
            cbmheader++;
        }
        else
        {
            /* found something, start from here */
            lp=ft[ldrtype].lp;
            sp=ft[ldrtype].sp;
            tp=ft[ldrtype].tp;
            en=ft[ldrtype].en;
            break;
        }
    }


    for(/*i=20*/; i<tap.len-8; i++)
    {
        if((nh>2)||(z=find_pilot(i,ldrtype))>0)
        {
            sof=i;
            if(nh<=2)
                i=z;

            /* sync = $80+$aa */
            for(cnt2=0; cnt2<2; cnt2++)
            {
                pat[cnt2] = readttbyte(i+(cnt2*8), lp, sp, tp, en);
            }
            if(((pat[0]==ft[ldrtype].sv && pat[1]==nseq)))
            {

                i=i+(cnt2*8);
                sod=i;
                if(e>s)
                {
                    x=e-s;
                    if(nh==1) /* read the 2nd block with 2nd loader and arrays */
                    {
                        for(cnt2=0; cnt2<x; cnt2++)
                        {
                            bufdata[cnt2] = readttbyte(i+(cnt2*8), lp, sp, tp, en);
                        }
                    }

                    eod=sod+(x*8);
                    eof=eod+16;
                    while(eof<tap.len-8)
                    {
                        if(readttbyte(eof, lp, sp, tp, en)!=0)
                            break;
                        eof+=8;
                    }
                    eof--;

                    xinfo=s|e<<16;
                    addblockdef(ldrtype, sof,sod,eod,eof, xinfo);
                    xinfo=0;
                    i=eof;   /* optimize search */

                    if(nh==0)
                    {

                        /* 2nd block */
                        s=bufd[0x2b]|bufd[0x2f]<<8;
                        e=bufd[0x33]|bufd[0x37]<<8;
                        //e--;

                    }
                    else if(nh==1)
                    {
                        s=bufdata[0x1cf8-0x1400    ]|bufdata[0x1cf9-0x1400    ]<<8; // 0x2400
                        e=bufdata[0x2000-0x1400 +nd]|bufdata[0x2100-0x1400 +nd]<<8;
                        nd++;
                    }
                    else
                    {
                        if(nd>=bufdata[0x22ff-0x1400])
                            break;
                        s=bufdata[0x2000-0x1400 +nd]|bufdata[0x2100-0x1400 +nd]<<8;
                        nd++;
                        e=bufdata[0x2000-0x1400 +nd]|bufdata[0x2100-0x1400 +nd]<<8;
                        nd++;

                    }
                    nh++;
                }
                else
                {
                    cnt2=0;
                    while(readttbyte(i, lp, sp, tp, en)==-1)
                    {
                        bufdata[cnt2] = readttbyte(i, lp, sp, tp, en);
                        i+=8;
                    }


                    break;

                }
            }
        }
    }
getout:
    if(!quiet&&lastldr)
        msgout("\n");

    if (bufd){ free(bufd);bufd=NULL;}
    if (bufh){ free(bufh);bufh=NULL;}
}
/*---------------------------------------------------------------------------
*/
int ff_describe(int row)
{

    int i,s;
    int b,cb,rd_err;
    int ldrtype=blk[row]->lt;
    int lp=ft[ldrtype].lp;
    int sp=ft[ldrtype].sp;
    int tp=ft[ldrtype].tp;
    int en=ft[ldrtype].en;

    /* decode header... */
    s= blk[row]->p2;

    /* compute C64 start address, end address and size...  */

    blk[row]->cs = blk[row]->xi&0xffff;
    blk[row]->ce =(blk[row]->xi>>16)/*-1*/;

    blk[row]->cx = (blk[row]->ce - blk[row]->cs) + 1;
    /* get pilot trailer lengths...  */
    blk[row]->pilot_len= (blk[row]->p2- blk[row]->p1 -8) >>3;
    blk[row]->trail_len= (blk[row]->p4- blk[row]->p3 -7) >>3;

    /* extract data... */
    rd_err=0;
    s= blk[row]->p2;
    cb=0;
    if(blk[row]->dd!=NULL)
        free(blk[row]->dd);
    blk[row]->dd = (unsigned char*)malloc(blk[row]->cx);

    for(i=0; i<blk[row]->cx; i++)
    {
        b=readttbyte(s+(i*8), lp, sp, tp, en);
        if(b==-1)
            rd_err++;

       // cb^=b;

        blk[row]->dd[i]= b;
    }

    //blk[row]->cs_exp= cb &0xFF;

    blk[row]->rd_err= rd_err;
    return 0;

}

